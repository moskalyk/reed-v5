export enum ChainId {
    MAINNET = 1,
    POLYGON = 137,
    KOVAN = 42,
}

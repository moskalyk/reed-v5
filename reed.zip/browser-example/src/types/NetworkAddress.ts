export interface NetworkAddress {
    [chainId: number]: string
}

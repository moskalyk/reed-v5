export const align = (s: string, length: number) => s.padEnd(length, " ")

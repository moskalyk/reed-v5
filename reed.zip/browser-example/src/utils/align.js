"use strict";
exports.__esModule = true;
exports.align = void 0;
var align = function (s, length) { return s.padEnd(length, " "); };
exports.align = align;

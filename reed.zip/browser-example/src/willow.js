// version 2, subtract everything below iching, deck fork for the people that play with iching
// really curious if another has got this

import { matchesPattern, tSExpressionWithTypeArguments } from "@babel/types"
import { isCommunityResourcable } from "@ethersproject/providers"
import { SubscriptionDistributionClaimedEventsDocument } from "@superfluid-finance/sdk-core/dist/module/subgraph/events/events.generated"

const elements = [17,23,29,31,37,41]
const elementsPure = ['fire',	'air',	'earth',	'metal',	'wood',	'water']
const combinationations = [
    ['fire+fire',	'air+fire',	'earth+fire',	'metal+fire',	'wood+fire',	'water+fire'],
    ['fire+air',	'air+air',	'earth+air',	'metal+air',	'wood+air',	'water+air'],
    ['fire+earth',	'air+earth',	'earth+earth',	'metal+earth',	'wood+earth',	'water+earth'],
    ['fire+metal',	'air+metal',	'earth+metal',	'metal+metal',	'wood+metal',	'water+metal'],
    ['fire+wood',	'air+wood',	'earth+wood',	'metal+wood',	'wood+wood',	'water+wood'],
    ['fire+water',	'air+water',	'earth+water',	'metal+water',	'wood+water',	'water+water']
]
const w1llow = [
    ['fire', 17],
    ['air',	23],
    ['earth', 29],
    ['metal', 31],
    ['wood', 37],
    ['water', 41],
    // 
    ['fire+fire', 34],
    ['fire+air', 30],
    ['fire+earth',46],
    ['fire+metal',48],
    ['fire+wood', 54],
    ['fire+water', 58],

    ['air+fire', 40],
    ['air+air', 46],
    ['air+earth',52],
    ['air+metal',52],
    ['air+wood', 60],
    ['air+water', 64],

    ['earth+fire', 46],
    ['earth+air', 52],
    ['earth+earth',58],
    ['earth+metal',60],
    ['earth+wood', 66],
    ['earth+water', 70],

    ['metal+fire', 48],
    ['metal+air', 54],
    ['metal+earth',60],
    ['metal+metal',62],
    ['metal+wood', 68],
    ['metal+water', 72],

    ['wood+fire', 54],
    ['wood+air', 60],
    ['wood+earth',66],
    ['wood+metal',68],
    ['wood+wood', 74],
    ['wood+water', 78],

    ['water+fire', 58],
    ['water+air', 64],
    ['water+earth',70],
    ['water+metal',72],
    ['water+wood', 78],
    ['water+water', 82],


    ['fire+fire+fire', 51],
    ['fire+air+fire', 57],
    ['fire+earth+fire', 63],
    ['fire+metal+fire', 65],
    ['fire+wood+fire', 71],
    ['fire+water+fire', 75],

    ['air+fire+fire', 57],
    ['air+air+fire', 63],
    ['air+earth+fire', 69],
    ['air+metal+fire', 71],
    ['air+wood+fire', 77],
    ['air+water+fire', 81],

    ['earth+fire+fire', 63],
    ['earth+air+fire', 69],
    ['earth+earth+fire', 75],
    ['earth+metal+fire', 77],
    ['earth+wood+fire', 83],
    ['earth+water+fire', 87],

    ['metal+fire+fire', 65],
    ['metal+air+fire', 71],
    ['metal+earth+fire', 77],
    ['metal+metal+fire', 79],
    ['metal+wood+fire', 85],
    ['metal+water+fire', 89],

    ['wood+fire+fire', 71],
    ['wood+air+fire', 77],
    ['wood+earth+fire', 83],
    ['wood+metal+fire', 85],
    ['wood+wood+fire', 91],
    ['wood+water+fire', 95],

    ['water+fire+fire', 75],
    ['water+air+fire', 81],
    ['water+earth+fire', 87],
    ['water+metal+fire', 89],
    ['water+wood+fire', 95],
    ['water+water+fire', 99],

    ['fire+fire+air', 57],
    ['fire+air+air', 63],
    ['fire+earth+air', 63],
    ['fire+metal+air', 71],
    ['fire+wood+air', 77],
    ['fire+water+air', 81],

    ['air+fire+air', 63],
    ['air+air+air', 69],
    ['air+earth+air', 69],
    ['air+metal+air', 77],
    ['air+wood+air', 83],
    ['air+water+air', 87],

    ['earth+fire+air', 69],
    ['earth+air+air', 75],
    ['earth+earth+air', 75],
    ['earth+metal+air', 83],
    ['earth+wood+air', 89],
    ['earth+water+air', 93],

    ['metal+fire+air', 77],
    ['metal+air+air', 83],
    ['metal+earth+air', 89],
    ['metal+metal+air', 91],
    ['metal+wood+air', 97],
    ['metal+water+air', 101],

    ['wood+fire+air', 77],
    ['wood+air+air', 83],
    ['wood+earth+air', 83],
    ['wood+metal+air', 91],
    ['wood+wood+air', 97],
    ['wood+water+air', 101],

    ['water+fire+air', 81],
    ['water+air+air', 87],
    ['water+earth+air', 87],
    ['water+metal+air', 95],
    ['water+wood+air', 101],
    ['water+water+air', 105],

    ['fire+fire+earth', 63],
    ['fire+air+earth', 69],
    ['fire+earth+earth', 75],
    ['fire+metal+earth', 77],
    ['fire+wood+earth', 83],
    ['fire+water+earth', 87],

    // ['wood+fire+air', 83],
    // ['wood+air+air', 89],
    // ['wood+earth+air', 95],
    // ['wood+metal+air', 97],
    // ['wood+wood+air', 103],
    // ['wood+water+air', 107],
]

// Hey welcome to the mattter.direct commmunity, 
// We're investigating whether you want to be of community help to those seeking means of spiritual support for people playing a new tarot deck called w1ll0w. 
// You've ranked within the sphere of first followers, and we want you take use your hands to build something together with many people.
// Your alchemical elements are '', and key number is 
// Some examples for cards would be as follows where this style would represent metal (), or you can source an artist from a recommended list of your choosing from https://twitter.com/torchhorse 
// ideally we will match 50% of the funds up to $175 for the artwork. We want to work with the many hands, so we use our subjective judgement

// We investigate key alchemical resources for fun & profit in order to weave the sublime. 

// We're trying to be kind to people's spaces and the collective research, 
// so if you don't respond there's a chance we go private & ban you from the community in order to gauge true success.


const fire = [
    	34,	40,	46,	48,	54,	58,
    	40, 46,	52,	54,	60,	64, // 20
    	46,	52,	58,	60,	66,	70,
    	48,	54,	60,	62,	68,	72,
    	54,	60,	66,	68,	74,	78,
    	58,	64,	70,	72,	78,	82
]

const fireFire = [
    51,	57,	63,	65,	71,	75,
    57,	63,	69,	71,	77,	81,
    63,	69,	75,	77,	83,	87,
    65,	71,	77,	79,	85,	89,
    71,	77,	83,	85,	91,	95,
    75,	81,	87,	89,	95,	99
]

const fireAir = [
    57,	63,	63,	71,	77,	81,
    63,	69,	69,	77,	83,	87,
    69,	75,	75,	83,	89,	93,
    71,	77,	77,	85,	91,	95,
    77,	83,	83,	91,	97,	101,
    81,	87,	87,	95,	101,	105
]

const fireEarth = [
    63,	69,	75,	77,	83,	87,
    69,	75,	81,	83,	89,	93,
    75,	81,	87,	89,	95,	99,
    77,	83,	89,	91,	97,	101,
    83,	89,	95,	97,	103,	107,
    87,	93,	99,	101,	107,	111
]

const fireMetal = [
    65,	71,	77,	79,	85,	89,
    71,	77,	83,	85,	91,	95,
    77,	83,	89,	91,	97,	101,
    79,	85,	91,	93,	99,	103,
    85,	91, 97,	99,	105,	109,
    89,	95,	101,	103,	109,	113
]

const fireWood = [
    71,	77,	63,	85,	91,	95,
    77,	83,	69,	91,	97,	101,
    83,	89,	75,	97,	103,	107,
    85,	91,	77,	99,	105,	109,
    91,	97,	83, 105,	111,	115,
    95, 101,	87,	109,	115,	119
]

const fireWater = [
    17,	75,	81,	87,	89,	95,	99,
    81,	87,	93,	95,	101,	105,
    87,	93,	99,	101,	107,	111,
    89,	95,	101,	103,	109,	113,
    95,	101,	107,	109,	115,	119,
    99,	105,	111,	113,	119,	123
]

export {
    elements,
    fire,
    fireFire,
    fireAir,
    fireEarth,
    fireMetal,
    fireWater,
    fireWood,
    elementsPure,
    combinationations,
    w1llow
}
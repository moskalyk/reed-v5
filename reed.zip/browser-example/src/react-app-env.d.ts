/// <reference types="react-scripts" />

interface Window {
  ethereum: any; // TODO: question for kartik
}
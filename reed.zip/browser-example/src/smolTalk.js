import { matchesPattern, tSExpressionWithTypeArguments } from "@babel/types"
import { isCommunityResourcable } from "@ethersproject/providers"
import { SubscriptionDistributionClaimedEventsDocument } from "@superfluid-finance/sdk-core/dist/module/subgraph/events/events.generated"

const smolTalk = [
    ["Has there been a time you've recieved a ton of information, and you found strength?", 1],
    ["What unrealized goal do you have?", 2],
    ["What is your longest running independent project that you are working on?", 3],
    ["Name a time when confidence helped in the face of danger.", 4],
    ["Name a time when you had to let your intelligence shine", 5],
    ["Can you tell me about a friend you found yourself open to?", 6],
    ["Where is your favourite path to walk?", 7],
    ["Can you name a time when you had to pull back your strength to find new efforts?", 8],
    ["When was the last time you changed your mind?", 9],
    ["Can you tell me about a time you found radical acceptance?", 10],
    ["What is your biggest concern with your digital privacy?", 11],
    ["Tell me about your family?", 12],
    ["What is your most stubborn matter?", 13],
    ["What was the biggest obstacle you've encountered?", 14],
    ["Do you have any memories in the rain?", 15],
    ["Can you tell me about a time you made a sacrifice for a family member or friend?", 16],
    ["Who do you like to follow online?", 17],
    ["If you could have 1000 true fans, what would it be for?", 18],
    ["What's your vice?", 19],
    ["Who's your favourite leader?", 20],
    ["If you could reach out to a leader to ask a question, what would it be and to whom?", 21],
    ["Can you tell me a time you were alone?", 22],
    ["What's a truth you stumbled on recently?", 23],
    ["What's your most memorable memory?", 24],
    ["What does your concept of God look like?", 25],
    ["What risk do you currently hold?", 26],
    ["Can you take us through a meditiation? If not, breath in for 4 counts, exhale for 3. Repeat.", 27],
    ["What's your favourite software app, line of code, project, etc.?", 28],
    ["Stare into the other person's eyes for 60 seconds.", 29],
    ["Can you name your biggest accolade or achievement?", 30],
    ["Where is your favourite place to travel?", 31],
]

export {
    smolTalk
}
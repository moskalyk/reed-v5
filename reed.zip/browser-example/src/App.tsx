import React, { useEffect, useState } from "react";

import logo from "./logo.svg";
import "./App.scss";
import { parseEther } from "ethers/lib/utils"
import FadeIn from 'react-fade-in';
import { ChainId } from "./types/ChainId"
// import SuperfluidSDK from '@superfluid-finance/js-sdk';
// import { Web3Provider } from '@ethersproject/providers';
// import { Framework } from "@superfluid-finance/sdk-core";
import { Framework } from "@superfluid-finance/sdk-core";
// import SuperfluidSDK from '@superfluid-finance/js-sdk';

// import Web3Modal from "web3modal";
import { Web3Provider } from "@ethersproject/providers";
import APWineSDK from '@apwine/sdk'
import { getTokenByAddress } from "./types/tokens"
import { align } from "./utils/align"
import { getToken } from "./types/tokens"
import { Fluence, KeyPair } from "@fluencelabs/fluence";
import { krasnodar } from "@fluencelabs/fluence-network-environment";
import { getRelayTime } from "./generated/reed";
import { sayHello, registerHelloPeer } from './_aqua/getting-started_hello';
import { 
  postReview, 
  getReducedReviews, 
  getAllReviews,
  getUniqueness, 
  registerReviews
} 
from './generated/reed';

import { balance } from "./utils/balance"
// import { ReactMic } from "./node_modules/react-mic/src/index.js";
import { Web3Storage } from 'web3.storage'
// import { depositLidoETH } from "./utils/depositLidoETH.js"
// import { depositConsole } from "./utils/depositLidoETH.js"
import { ethFloat } from "./utils/ethFloat"
import stringCard from './stack8.png'

import { useAccount, useConnect, useDisconnect } from 'wagmi'
import { InjectedConnector } from 'wagmi/connectors/injected'
import {ethers} from 'ethers'
import library from './talis.js'

import {
  elements,
  fire,
  fireFire,
  fireAir,
  fireEarth,
  fireMetal,
  fireWater,
  fireWood,
  elementsPure,
  combinationations,
  w1llow
} from './willow.js'

import {
  smolTalk
} from './smolTalk.js'
import { TradeType } from "@uniswap/sdk";

const PEER_ID="12D3KooWKqiPrwbHnvqxCSUbhbumF8GSJW5MrnuPDYpMTh1yJMh5"
const TARGET_RELAY_ID ="12D3KooWSD5PToNiLQwKDXsu8JSysCwUt8BVUJEqCHcDe7P5h45e"

const urbit = require('urbit-ob');

const relayNode = krasnodar[0];

const relayNodes = [krasnodar[4], krasnodar[5], krasnodar[6]];

let cards;

let tarot = [
  ['The Fool','https://www.trustedtarot.com/img/cards/the-fool.png'],
  ['The Magician','https://www.trustedtarot.com/img/cards/the-magician.png'],
  ['The High Priestess','https://www.trustedtarot.com/img/cards/the-high-priestess.png'],
  ['The Empress','https://www.trustedtarot.com/img/cards/the-empress.png'],
  ['The Emperor','https://www.trustedtarot.com/img/cards/the-emperor.png'],
  ['The Hierophant','https://www.trustedtarot.com/img/cards/the-heirophant.png'],
  ['The Lovers','https://www.trustedtarot.com/img/cards/the-lovers.png'],
  ['The Chariot','https://www.trustedtarot.com/img/cards/the-chariot.png'],
  ['Fortitude','https://www.trustedtarot.com/img/cards/strength.png'],
  ['The Hermit','https://www.trustedtarot.com/img/cards/the-hermit.png'],
  ['Wheel Of Fortune','https://www.trustedtarot.com/img/cards/wheel-of-fortune.png'],
  ['Justice','https://www.trustedtarot.com/img/cards/justice.png'],
  ['The Hanged Man','https://www.trustedtarot.com/img/cards/the-hanged-man.png'],
  ['Death','https://www.trustedtarot.com/img/cards/death.png'],


  ['Temperance','https://www.trustedtarot.com/img/cards/temperance.png'],
  ['The Devil','https://www.trustedtarot.com/img/cards/the-devil.png'],
  ['The Tower','https://www.trustedtarot.com/img/cards/the-tower.png'],
  ['The Star','https://www.trustedtarot.com/img/cards/the-star.png'],
  ['The Moon','https://www.trustedtarot.com/img/cards/the-moon.png'],
  ['The Sun','https://www.trustedtarot.com/img/cards/the-sun.png'],
  ['Judgement','https://www.trustedtarot.com/img/cards/judgement.png'],
  ['The World','https://www.trustedtarot.com/img/cards/the-world.png'],


  ['King of Cups','https://www.trustedtarot.com/img/cards/king-of-cups.png'],
  ['Queen of Cups','https://www.trustedtarot.com/img/cards/queen-of-cups.png'],
  ['Knight of Cups','https://www.trustedtarot.com/img/cards/knight-of-cups.png'],
  ['Page of Cups','https://www.trustedtarot.com/img/cards/page-of-cups.png'],
  ['X of Cups','https://www.trustedtarot.com/img/cards/ten-of-cups.png'],
  ['IX of Cups','https://www.trustedtarot.com/img/cards/nine-of-cups.png'],
  ['VIII of Cups','https://www.trustedtarot.com/img/cards/eight-of-cups.png'],
  ['VII of Cups','https://www.trustedtarot.com/img/cards/seven-of-cups.png'],
  ['VI of Cups','https://www.trustedtarot.com/img/cards/six-of-cups.png'],
  ['V of Cups','https://www.trustedtarot.com/img/cards/five-of-cups.png'],
  ['IV of Cups','https://www.trustedtarot.com/img/cards/four-of-cups.png'],
  ['III of Cups','https://www.trustedtarot.com/img/cards/three-of-cups.png'],
  ['II of Cups','https://www.trustedtarot.com/img/cards/two-of-cups.png'],
  ['Ace of Cups','https://www.trustedtarot.com/img/cards/ace-of-cups.png'],
  ['King of Swords','https://www.trustedtarot.com/img/cards/king-of-swords.png'],
  ['Queen of Swords','https://www.trustedtarot.com/img/cards/queen-of-swords.png'],
  ['Knight of Swords','https://www.trustedtarot.com/img/cards/knight-of-swords.png'],
  ['Page of Swords','https://www.trustedtarot.com/img/cards/page-of-swords.png'],
  ['X of Swords','https://www.trustedtarot.com/img/cards/ten-of-swords.png'],
  ['IX of Swords','https://www.trustedtarot.com/img/cards/nine-of-swords.png'],
  ['VIII of Swords','https://www.trustedtarot.com/img/cards/eight-of-swords.png'],
  ['VII of Swords','https://www.trustedtarot.com/img/cards/seven-of-swords.png'],
  ['VI of Swords','https://www.trustedtarot.com/img/cards/six-of-swords.png'],
  ['V of Swords','https://www.trustedtarot.com/img/cards/five-of-swords.png'],
  ['IV of Swords','https://www.trustedtarot.com/img/cards/four-of-swords.png'],
  ['III of Swords','https://www.trustedtarot.com/img/cards/three-of-swords.png'],
  ['II of Swords','https://www.trustedtarot.com/img/cards/two-of-swords.png'],
  ['Ace of Swords','https://www.trustedtarot.com/img/cards/ace-of-swords.png'],
  ['King of Wands','https://www.trustedtarot.com/img/cards/king-of-wands.png'],
  ['Queen of Wands','https://www.trustedtarot.com/img/cards/queen-of-wands.png'],
  ['Knight of Wands','https://www.trustedtarot.com/img/cards/knight-of-wands.png'],
  ['Page of Wands','https://www.trustedtarot.com/img/cards/page-of-wands.png'],
  ['X of Wands','https://www.trustedtarot.com/img/cards/ten-of-wands.png'],
  ['IX of Wands','https://www.trustedtarot.com/img/cards/nine-of-wands.png'],
  ['VIII of Wands','https://www.trustedtarot.com/img/cards/eight-of-wands.png'],
  ['VII of Wands','https://www.trustedtarot.com/img/cards/seven-of-wands.png'],
  ['VI of Wands','https://www.trustedtarot.com/img/cards/six-of-wands.png'],
  ['V of Wands','https://www.trustedtarot.com/img/cards/five-of-wands.png'],
  ['IV of Wands','https://www.trustedtarot.com/img/cards/four-of-wands.png'],
  ['III of Wands','https://www.trustedtarot.com/img/cards/three-of-wands.png'],
  ['II of Wands','https://www.trustedtarot.com/img/cards/two-of-wands.png'],
  ['Ace of Wands','https://www.trustedtarot.com/img/cards/ace-of-wands.png'],
  ['King of Pentacles','https://www.trustedtarot.com/img/cards/king-of-pentacles.png'],
  ['Queen of Pentacles','https://www.trustedtarot.com/img/cards/queen-of-pentacles.png'],
  ['Knight of Pentacles','https://www.trustedtarot.com/img/cards/knight-of-pentacles.png'],
  ['Page of Pentacles','https://www.trustedtarot.com/img/cards/page-of-pentacles.png'],
  ['X of Pentacles','https://www.trustedtarot.com/img/cards/ten-of-pentacles.png'],
  ['IX of Pentacles','https://www.trustedtarot.com/img/cards/nine-of-pentacles.png'],
  ['VIII of Pentacles','https://www.trustedtarot.com/img/cards/eight-of-pentacles.png'],
  ['VII of Pentacles','https://www.trustedtarot.com/img/cards/seven-of-pentacles.png'],
  ['VI of Pentacles','https://www.trustedtarot.com/img/cards/six-of-pentacles.png'],
  ['V of Pentacles','https://www.trustedtarot.com/img/cards/five-of-pentacles.png'],
  ['IV of Penatcles','https://www.trustedtarot.com/img/cards/four-of-pentacles.png'],
  ['III of Pentacles','https://www.trustedtarot.com/img/cards/three-of-pentacles.png'],
  ['II of Pentacles','https://www.trustedtarot.com/img/cards/two-of-pentacles.png'],
  ['Ace of Pentacles','https://www.trustedtarot.com/img/cards/ace-of-pentacles.png'],
]

const n3pthora = [
  ['Strength','https://i.ibb.co/7Ktj6vr/0x01-strength.png" alt="0x01-strength','Strength of Love providing support to see with courage in points of massive potential to make impact.'],
  // ['Strength','https://i.ibb.co/7Ktj6vr/0x01-strength.png" alt="0x01-strength','Strength of Love providing support to see with courage in points of massive potential to make impact.'],
  ['Community','https://i.ibb.co/XYBgMtR/0x02-community.png','Time to take a stroll in the community, evaluate bias, see what what guides you and make better judgements for inspiring double edged decisions.'],
  ['Shared Emotion','https://i.ibb.co/Y70kh0n/0x03-shared-emotion.png','Considering the fox and the swan totem to find moments of time to share emotions of free will in contemplating kindness. Might be time for a gift.'],
  ['Past Obstacles','https://i.ibb.co/3f4JcX4/0x04-past-obstacles.png','Moving past an obstacle, allowing one to give rise to new opportunity in the little details. Appreciate a cloud, a plant, a tree.'],
  ['Chariot Moving','https://i.ibb.co/cDwQQGh/0x05-dapr-chariot.png','Time to move forward with the dark & light of the chariot, giving rise to the star alignments, responsive to the woven nature of life.'],
]

const spreadTypes = [
'Past-Present-Future',
'9-Card Jung',
'Celtic Cross',
]

const cardStorage = [
  localStorage.getItem(String(0)),
  localStorage.getItem(String(1)),
  localStorage.getItem(String(2)),
  localStorage.getItem(String(3)),
  localStorage.getItem(String(4)),
  localStorage.getItem(String(5)),
  localStorage.getItem(String(6)),
  localStorage.getItem(String(7)),
]

class Bar {
  html
  id
  constructor(id, cycle, color){
    this.html = <div className="chart">
                <div className={`bar bar-30 ${color}`}>
                    <div className="face top">
                        <div id={`bar-cycle-${id}-top`} className="growing-bar"></div>
                    </div>
                    <div className="face side-0">
                        <div id={`bar-cycle-${id}-bottom`} className="growing-bar"></div>
                    </div>
                    <div className="face floor">
                        <div id={`bar-cycle-${id}-left`} className="growing-bar"></div>
                    </div>
                    <div className="face side-a"></div>
                    <div className="face side-b"></div>
                    <div className="face side-1">
                        <div id={`bar-cycle-${id}-right`} className="growing-bar"></div>
                    </div>
                </div>
                <h1 className="title">{cycle}</h1>
                <br/>
            </div>
    this.id = id
  }
  open(){
    return this.html;
  }
  static accelerate(id, velocity){
    try{
      if(document != null){
        // console.log(`bar-cycle-${id}-top`)
        // console.log(document.getElementById(`bar-cycle-${id}-top`))
        document.getElementById(`bar-cycle-${id}-top`)!.style.width = `${velocity}%`
        document.getElementById(`bar-cycle-${id}-bottom`)!.style.width = `${velocity}%`
        document.getElementById(`bar-cycle-${id}-left`)!.style.width = `${velocity}%`
        document.getElementById(`bar-cycle-${id}-right`)!.style.width = `${velocity}%`
      }
    }catch(e){
      console.log(e)
    }
  }
  static close(id){
    if(document != null){
      document.getElementById(`bar-cycle-${id}-top`)!.style.width = '0%'
      document.getElementById(`bar-cycle-${id}-bottom`)!.style.width = '0%'
      document.getElementById(`bar-cycle-${id}-left`)!.style.width = '0%'
      document.getElementById(`bar-cycle-${id}-right`)!.style.width = '0%'
    }
  }
}

function Reed(props) {

  const pullCards = () => {
    console.log('pulling')
    props.setRenderer(2)
    count = 0
    props.setAssembled(false)
    clearInterval(intervalPull)
  }

  return(
    <div className="App">
        {/*<canvas id="ring"></canvas>*/}
        <h1 className="title">Reed</h1>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <a target="_blank" style={{cursor: 'pointer'}}href={"https://github.com/deep6org/reed-terms-and-consent/blob/main/README.md"}><p>consent to terms</p></a>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <FadeIn>
        {/*<img style={{width: '30%'}}src="https://i.ibb.co/FxLPhpg/IMG-6928.gif"/>*/}
          <div className="container">
            <div className="vertical-center">
              <div className="btn btn__secondary" onClick={()=> pullCards()}><a><p>i n t e n t i o n</p></a></div>
            </div>
          </div>
          <br/>
          <br/>
          <br/>

          <br/>

          <div className="container">
            <div className="vertical-center">
              <div className="btn btn__secondary" onClick={()=> props.setRenderer(10)}><a><p>p r o f i l e</p></a></div>
            </div>
          </div>
        <br/>
        </FadeIn>
        {/*TODO: banner with clock aligned with wheel and 9/6*/}
        <Banner/>
    </div>
  )
}

function CardMemStore() {
  return 
}

// TODO: fix with multi-spread
let oneCard = null
let twoCard = null
let threeCard = null
function oneOf(i) {
    let cards = [oneCard,twoCard,threeCard]
    // let cards = [49,27,13]
    for(let j = 0; j < cards.length; j++) {
        if (cards[j] != null && cards[j] == i){
            return false;
        }
    }
    return true
}

const matter = async (peerId, deckNumeric, compute = 'φ') => {
  let number;
  if(compute == '~'){
    // looped, 
    // computers, seeded from card shared secret
  }else {
    console.log(peerId)
    console.log(deckNumeric)
    const relayTime = await getRelayTime(peerId)
    // number = Math.floor(Array.from((Array(relayTime % deckNumeric).keys()).filter().reduce((x,y) => x + Math.abs(Math.tan(y)))%deckNumeric)
    number = Math.floor((Array.from(Array(relayTime % deckNumeric).keys()).filter((i) => {console.log(oneOf(i)); return oneOf(i)})).reduce((x,y) => x + Math.abs(Math.tan(y)))%deckNumeric)
  }
  return number
}

let count = 0; // who's tweeting off my alt
let deck = 0; // 1) What
let intervalPull;
function Spread(props){

  const [holoDeck, setHoloDeck] = useState<any>()
  // hack
  const [past, setPast] = useState<any>()
  const [present, setPresent] = useState<any>()
  const [future, setFuture] = useState<any>()

  const stake = async (cardStake, context) => {
    console.log('staking')
    console.log(cardStake)

    const nonce = localStorage.getItem('nonce')

    if(nonce != null ){

    // Array(8).

      Array.from(Array(8).keys()).map((i) => {
        const stored = localStorage.getItem(String(i % 8))
        if(stored != null){
          localStorage.setItem(String(Number(nonce) % 8), cardStake);
          localStorage.setItem(`time:${String(Number(nonce) % 8)}:${context}`, String(Date.now()))
        } else {
          localStorage.setItem(String(Number(nonce) % 8), cardStake);
          localStorage.setItem(`time:${String(Number(nonce) % 8)}:${context}`, String(Date.now()))
        }
      })

      localStorage.setItem('nonce', String(Number(nonce)+1))
    }
  }

  const see = () => {
    console.log('see')
    props.setRenderer(4)
  }

  // const pullCards = async() => {
  //   console.log('pulling')
  //   // connnect to wallet

  //   // MetaMask requires requesting permission to connect users accounts
  //   await provider.send("eth_requestAccounts", []);

  //   const signer = provider.getSigner()

  //   console.log(signer)

  //   const sdk: APWineSDK = new APWineSDK({ provider, signer, network: 1 })
  //   await sdk.ready

  //   props.setRenderer(2)
  // }

  useEffect(() => {
    if(!props.assembled){
      intervalPull = setInterval(async () => {

        let deckNumeric;
        let number;

        if(props.deck == 0){
          deckNumeric = 78
          cards = tarot
        } else if(props.deck == 1){
          deckNumeric = 5
          cards = n3pthora
        }
        else if (props.deck == 2){
          deckNumeric = 35
          // const willow = fire.concat(fireAir).concat(fireEarth).concat(fireFire).concat(fireMetal).concat(fireWater).concat(fireWood)
          cards = w1llow
        }else if (props.deck == 3){
          deckNumeric = 40
          cards = w1llow
        } else if (props.deck == 4){
          deckNumeric = 31
          cards = smolTalk
        }

        if(props.deck == 1 || props.deck == 0 ){

        switch(count){
          case 1:
            number = await matter(props.relayNode.peerId, deckNumeric)
            // number = Math.floor(Math.random() * deckNumeric)

            oneCard = number
            // document.getElementsByClassName('card')[0].style.backgroundUrl = 'https://www.trustedtarot.com/img/cards/strength.png'
            setPast(
              <>
                <div className="wrapper" >
                <p className="sub">past</p>
                <div className={`card ${'charizard'} animated`}>
                  <img width="100%" src={cards[number][1]} />
                </div>
                <div className="botn sub" onClick={() => stake(cards[number][1], 'past')}><a href="#">Stake</a></div>
                </div>
              </>
              )

            break
          case 2:
            number = await matter(props.relayNode.peerId, deckNumeric)
            //number = Math.floor(Math.random() * deckNumeric)

            twoCard = number
            setPresent(
              <>
              <div className="wrapper" >
                <p className="sub">present</p>
                <div className="card mewtwo animated">
                  <img width="100%" src={cards[number][1]} />
                </div>
                <div className="botn sub" onClick={() => stake(cards[number][1], 'present')}><a href="#">Stake</a></div>
                </div>
              </>
              )

            break
          case 3:
            number = await matter(props.relayNode.peerId, deckNumeric)
            //number = Math.floor(Math.random() * deckNumeric)

            threeCard = number
            setFuture(
              <>
              <div className="wrapper" >
                <p className="sub">future</p>
                <div className="card eevee animated">
                  <img width="100%" src={cards[number][1]} />
                </div>
                <br/>

                <div className="botn sub" onClick={() => stake(cards[number][1], 'future')}><a href="#">Stake</a></div>
                </div>
              </>
              )

            break
          default:
            break;
        }
      } else {
        switch(count){
          case 1:
            number = await matter(props.relayNode.peerId, deckNumeric)
            //number = Math.floor(Math.random() * deckNumeric)

            oneCard = number
            if(oneCard){
            // document.getElementsByClassName('card')[0].style.backgroundUrl = 'https://www.trustedtarot.com/img/cards/strength.png'
            setPast(
              <>
                <div className="wrapper" >
                <p className="sub">past</p>
                <div className={`card-w1llow animated`}>
                  <h1 style={{marginTop: '50%'}}>{cards[oneCard][0]}</h1>
                  <h1 style={{marginTop: '10%'}}>{cards[oneCard][1]}</h1>

                </div>
                <br/>
                <div className="botn sub" onClick={() => stake(`${cards[number][0]}:${cards[number][1]}`, 'past:number')}><a href="#">Stake</a></div>
                </div>
              </>
              )
            }
            break
          case 2:
            number = await matter(props.relayNode.peerId, deckNumeric)
            //number = Math.floor(Math.random() * deckNumeric)

            twoCard = number

            if(twoCard){
              setPresent(
                <>
                <div className="wrapper" >
                  <p className="sub">present</p>
                  <div className={`card-w1llow animated`}>
                    <h1 style={{marginTop: '50%'}}>{cards[twoCard][0]}</h1>
                    <h1 style={{marginTop: '10%'}}>{cards[twoCard][1]}</h1>
                  </div>
                  <br/>
                  <br/>

                  <div className="botn sub" onClick={() => stake(`${cards[number][0]}:${cards[number][1]}`, 'present:numbers')}><a href="#">Stake</a></div>
                  </div>
                </>
              )
            }

            break
          // case 4:
          //   number = await matter(props.relayNode.peerId, deckNumeric)
          //   threeCard = number
          //   if(threeCard){

          //   setFuture(
          //     <>
          //     <div className="wrapper" >
          //       <p className="sub">future</p>
          //       <div className={`card-w1llow animated`}>
          //           {cards[threeCard]}
          //         </div>
          //       <br/>
          //       <br/>

          //       <div className="botn sub" onClick={() => stake(cards[number][1], 'future')}><a href="#">Stake</a></div>
          //       </div>
          //     </>
          //     )
          //   }
          //   break
          default:
            break;
        }
      }

        count ++
      }, 1260)
      props.setAssembled(true)
    }
  })
  return(
    <>
      <h1 className="title">Spread</h1>
        {/*<img width={"120%"} height={'100%'} src={deck['The Magician']}/>*/}
      <br/>
      <br/>
      <br/>
      <br/>
        <div className="container">
            <div className="vertical-center">
              <div className="btn btn__secondary" onClick={()=> see()}><p>s e e &nbsp;&nbsp; s t a k e</p></div>
            </div>
          </div>
        <FadeIn>
        <section className="cards">
        {past}
        {present}
        {future}
        </section>
        </FadeIn>
      <Banner/>
    </>
  )
}

// TODO: fix rootStore
let remote = false;
function RootStore(index, storage = localStorage) {

  if(remote){
    console.log('RUNNING_REMOTE')
    // return 
    const time = storage.getItem(`time:${index % 8}`)
    const cursor = storage.getItem(`share:cards:${index}`)

    return cursor != null ? {cursor: cursor, time: time} : undefined
  }
  const cursor = storage.getItem(index)
  const time = storage.getItem(`time:${index % 8}`)
  // console.log('time')
  // console.log(`time:${index % 8}`)
  // console.log(time)
  return cursor != null ? {cursor: cursor, time: time} : undefined
}

function ShareStore(index, storage = localStorage) {
  console.log('share')
  console.log('share')
  // storage.setItem(`share:cards${index % 8}`, peerId)
  const shared = storage.getItem(`share:cards${index % 8}`)
  console.log(shared)
  return shared != null ? shared : undefined
}

function Light(){}

function Aura(context, storage = localStorage) {
  let tri: any = []
  for(let i = 0; i < 8; i++){
    if(storage.getItem(`time:${i % 8}:${context}`) != undefined){
      tri.push(storage.getItem(`time:${i % 8}:${context}`))
    }
  }
  return tri
}

Light.prototype.past = function(){
  // console.log('PAST')
  return Aura('past')
}

Light.prototype.present = function(){
  return Aura('present')
}

Light.prototype.future = function(){
  return Aura('future')
}

function stem(seed){
  console.log('STEM')
  const head = seed[0]
  const tail = seed[seed.length - 1]
  console.log(head)
  console.log(tail)
  // Number
  const date1 = Number(new Date(head));
  const date2 = Number(new Date(tail));
  // Math.abs(date2 - date1)
  console.log('date1')

  const diffTime = Math.abs(date2 - date1);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
  console.log(diffDays)
  // console.log(diffDays == NaN)
  // return isNaN(diffDays) ? 1 : diffDays 
  return seed.length 
}

function Apple(seed, context){
  console.log(context)
  console.log('seed')
  console.log(seed)
  const rate = 7.5 // 28 days
  // const date1 = new Date('7/13/2010');
  const span = stem(seed)
  console.log('span')
  console.log(span)
  // const date1 = new Date('7/13/2010');
  const date1 = Number(new Date(Date.now()));
  const date2 = Number(new Date(new Date(new Date().getTime()+(28*24*60*60*1000))));
  const diffTime = Math.abs(date2 - date1);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
  console.log(diffTime + " milliseconds");
  console.log(diffDays + " days");
  console.log(rate / span * 13.333)
  return rate / span * 13.333
}
function Banner(){

  useEffect(() => {
    // const dropdownComponent1 = 

  })

  return(
    <div className="banner-whl">
          {/*<span className="dial-in">☿</span><span className="blink_me">⛢</span><span className="to-dial-in">☉</span>*/}
      </div>
  )
}

let varelayPeerIdInput = ''
let vapeerIdInput = ''
let cd = ''
function Audio(props: any) {
    const [isConnected, setIsConnected] = useState<boolean>(false);
    const [helloMessage, setHelloMessage] = useState<string | null>(null);
    const [relayPeerIdInput, setRelayPeerIdInput] = useState<string>('');
    const [peerIdInput, setPeerIdInput] = useState<string>('');

      const [tube, setTube] = useState(0)
  const [horo, setHoro] = useState(false)
  const [record, setRecord] = useState(false)
  const [recordState, setRecordState] = useState(false)
  const [myAudioSrc, setMyAudioSrc] = useState<string[]>([]);
  const [audioStack, setAudioStack] = useState<any[]>([])
  const [messages, setMessages] = useState<any[]>([])

  const click = async () => {
    console.log(getAccessToken())
    switch(tube){
    case 0:
      start()
      break;
    case 1:
      stop()
      break;
    }

    setTube(current => {
      return current + 1
    })

    if(tube >= 1) {
      setTube(0)
      setRecord(false)
    }
  }

  const start = () => {
    console.log('start')
    setRecord(true)
  }

  const stop = () => {
    console.log('stop')
    setRecord(false)
  }

  async function storeFiles (files: any[], helloBtnOnClick: any) {
  const client = makeStorageClient()
  const cid = await client.put(files)
  console.log('stored files with cid:', cid)
  // console.log(peerIdInput)
  // console.log(relayPeerIdInput)
  // const res = await sayHello(vapeerIdInput, varelayPeerIdInput);
  // console.log(res)
  cd = cid
  helloBtnOnClick()
  return cid
}

  const onStop = async (recordedBlob: any) => {
    console.log("recordedBlob is: ", recordedBlob);
    console.log("peerIdInput is: ", peerIdInput);
    console.log("relayPeerIdInput is: ", relayPeerIdInput);
    var url = URL.createObjectURL(recordedBlob.blob);
    // setMyAudioSrc(url);
    // console.log(url)
    setMyAudioSrc(current => [...current, ...[url]])
    await storeFiles(makeFileObjects(recordedBlob), helloBtnOnClick)
    // await storeFiles(makeFileObjects({test: 'radio'}))
  };
      useEffect(() => {
        const audio = myAudioSrc.map((audioEl) => {
          return <audio controls id="myAudio" src={audioEl}></audio>
        })
        setAudioStack(audio)
      }, [myAudioSrc])

    const connect = async (relayPeerId: string) => {
        // console.log('setting')
        // console.log(relayPeerId)
        // console.log(relayPeerId)
        // props.setRelayPeerIdInput(relayPeerId)
        // console.log(props.relayPeerId)
        // relayPeerIdInput = 
        try {
            await Fluence.start({ connectTo: relayPeerId });
            setIsConnected(true);
            // Register handler for this call in aqua:
            // HelloPeer.hello(%init_peer_id%)
            registerHelloPeer({
                hello: (from) => {
                    setHelloMessage('Hello from: \n' + from);
                    return ""+[RootStore(0)?.cursor, RootStore(1)?.cursor, RootStore(2)?.cursor, RootStore(3)?.cursor, RootStore(4)?.cursor, RootStore(5)?.cursor, RootStore(6)?.cursor, RootStore(7)?.cursor];
                },
            });
        } catch (err) {
            console.log('Peer initialization failed', err);
        }
    };

    const helloBtnOnClick = async () => {
        if (!Fluence.getStatus().isConnected) {
            return;
        }
        console.log('peerIdInput, relayPeerIdInput')
        console.log(vapeerIdInput, varelayPeerIdInput)
        // Using aqua is as easy as calling a javascript funсtion
        const res = await sayHello(vapeerIdInput, varelayPeerIdInput);
        setHelloMessage(res);
    };

    return (
        <div className="App">
            <div className="content">
                {isConnected ? (
                    <>
                        <h1>Connected</h1>
                        <table>
                            <tbody>
                                <tr>
                                    <td className="bold">Peer id:</td>
                                    <td className="mono">
                                        <span id="peerId">{Fluence.getStatus().peerId!}</span>
                                    </td>
                                    <td>
                                        <button
                                            className="btn-clipboard"
                                            onClick={() => copyToClipboard(Fluence.getStatus().peerId!)}
                                        >
                                            <i className="gg-clipboard"></i>
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td className="bold">Relay peer id:</td>
                                    <td className="mono">
                                        <span id="relayId">{Fluence.getStatus().relayPeerId}</span>
                                    </td>
                                    <td>
                                        <button
                                            className="btn-clipboard"
                                            onClick={() => copyToClipboard(Fluence.getStatus().relayPeerId!)}
                                        >
                                            <i className="gg-clipboard"></i>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <div>
                            <h2>Say hello!</h2>
                            <p className="p">
                                Now try opening a new tab with the same application. Copy paste the peer id and relay
                                from the second tab and say hello!
                            </p>
                            <div className="row">
                                <label className="label bold">Target peer id</label>
                                <input
                                    id="targetPeerId"
                                    className="input"
                                    type="text"
                                    onChange={(e) => {
                                        setPeerIdInput(e.target.value)
                                        vapeerIdInput = e.target.value
                                    }}
                                    value={peerIdInput}
                                />
                            </div>
                            <div className="row">
                                <label className="label bold">Target relay</label>
                                <input
                                    id="targetRelayId"
                                    className="input"
                                    type="text"
                                    onChange={(e) => {
                                        setRelayPeerIdInput(e.target.value)
                                        varelayPeerIdInput = e.target.value
                                    }}
                                    value={relayPeerIdInput}
                                />
                            </div>
                            <div className="App">
                                  <a style={{cursor: 'pointer', fontSize: '40px'}}onClick={click}>{va[tube]}</a>
                                  <br/>
                                  <br/>
                                  <br/>
                                  <br/>
                                  {/* <ReactMic
                                      record={record}
                                      className="sound-wave"
                                      onStop={onStop}
                                      strokeColor="#000000"
                                      backgroundColor="#FF4081" /> */}
                                  <br/>
                                  {relayPeerIdInput}
                                  <br/>
                                  <br/>
                                    {audioStack}
                                    {messages}
                                  <br/>
                                  <br/>
                                </div>
                            <div className="row">
                                <button className="btn btn-hello" onClick={helloBtnOnClick}>
                                    say hello
                                </button>
                            </div>
                        </div>
                    </>
                ) : (
                    <>
                        <h1>Intro 1: P2P browser-to-browser</h1>
                        <h2>Pick a relay</h2>
                        <ul>
                            {relayNodes.map((x) => (
                                <li key={x.peerId}>
                                    <span className="mono">{x.peerId}</span>
                                    <button className="btn" onClick={() => connect(x.multiaddr)}>
                                        Connect
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </>
                )}

                {helloMessage && (
                    <>
                        <h2>Message</h2>
                        <div id="message"> {helloMessage} </div>
                    </>
                )}
            </div>
        </div>
    );
}

function getAccessToken () {
  // If you're just testing, you can paste in a token
  // and uncomment the following line:
  // return 'paste-your-token-here'

  // In a real app, it's better to read an access token from an
  // environement variable or other configuration that's kept outside of
  // your code base. For this to work, you need to set the
  // WEB3STORAGE_TOKEN environment variable before you run your code.
  return "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkaWQ6ZXRocjoweGRjMDQ4M2Y1M2UxZDAxQzk4M2U3NTQxRTMzNjhBMEVjMzc1QTc3NDgiLCJpc3MiOiJ3ZWIzLXN0b3JhZ2UiLCJpYXQiOjE2NjgyNjIxNDkyNzksIm5hbWUiOiJyZWVkIn0.NofDSMbuIq0piTz9koErMeMcNkMIl_W8jFPI_O2um54"
}

function makeFileObjects (obj: any) {
  // You can create File objects from a Blob of binary data
  // see: https://developer.mozilla.org/en-US/docs/Web/API/Blob
  // Here we're just storing a JSON object, but you can store images,
  // audio, or whatever you want!
  const blob = new Blob([JSON.stringify(obj)], { type: 'application/json' })

  const files = [
    new File([blob], 'hello.json')
  ]
  return files
}



function makeStorageClient () {
  return new Web3Storage({ token: getAccessToken() })
}

const va = ['𓂍','⧭']

let hack = 0
// let relayPeerIdInput = ''
// let peerIdInput = ''
// function VaEmit(props: any) {
//   const [tube, setTube] = useState(0)
//   const [horo, setHoro] = useState(false)
//   const [record, setRecord] = useState(false)
//   const [recordState, setRecordState] = useState(false)
//   const [myAudioSrc, setMyAudioSrc] = useState<string[]>([]);
//   const [audioStack, setAudioStack] = useState<any[]>([])
//   const [messages, setMessages] = useState<any[]>([])

//   const click = async () => {
//     console.log(getAccessToken())
//     switch(tube){
//     case 0:
//       start()
//       break;
//     case 1:
//       stop()
//       break;
//     }

//     setTube(current => {
//       return current + 1
//     })

//     if(tube >= 1) {
//       setTube(0)
//       setRecord(false)
//     }
//   }

//   const start = () => {
//     console.log('start')
//     setRecord(true)
//   }

//   const stop = () => {
//     console.log('stop')
//     setRecord(false)
//   }

//   const onStop = async (recordedBlob: any) => {
//     console.log("recordedBlob is: ", recordedBlob);
//     console.log("peerIdInput is: ", props.peerIdInput);
//     console.log("relayPeerIdInput is: ", props.relayPeerIdInput);
//     var url = URL.createObjectURL(recordedBlob.blob);
//     // setMyAudioSrc(url);
//     // console.log(url)
//     setMyAudioSrc(current => [...current, ...[url]])
//     await storeFiles(makeFileObjects(recordedBlob), props.peerIdInput, props.relayPeerIdInput)
//     // await storeFiles(makeFileObjects({test: 'radio'}))
//   };

//   useEffect(() => {
//     const audio = myAudioSrc.map((audioEl) => {
//       return <audio controls id="myAudio" src={audioEl}></audio>
//     })
//     setAudioStack(audio)
//   }, [myAudioSrc])

//   return (
//     <div className="App">
//       <a style={{cursor: 'pointer', fontSize: '40px'}}onClick={click}>{va[tube]}</a>
//       <br/>
//       <br/>
//       <br/>
//       <br/>
//       <ReactMic
//           record={record}
//           className="sound-wave"
//           onStop={onStop}
//           strokeColor="#000000"
//           backgroundColor="#FF4081" />
//       <br/>
//       {props.relayPeerIdInput}
//       <br/>
//       <br/>
//         {audioStack}
//         {messages}
//       <br/>
//       <br/>
//     </div>
//   );
// }

const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
};

class _ {
  static limit(value, min, max) {
      return Math.min(Math.max(value, min), max);
  }

  static protectNumber(value, fallbackValue) {
      return typeof value === 'number' ? value : fallbackValue;
  }
}


class CanvasExample {
  static CSS_ROOT = 'canvas-example';
  static CSS_ROOT_LOADED_VARIANT = '-loaded';

  static DEFAULT_CLEAR_COLOR = '#000000';
  static DEFAULT_PAINT_COLOR = '#ffffff';
  static DEFAULT_FADE_COLOR  = 'rgba(0, 0, 0, 0.2)';
  static DEFAULT_DEBUG_MODE  = false;
  static DEFAULT_SIZE_MODIFIER = 0.5;

  root;
  canvas;
  context;
  frameRequestId;

  sizeModifier;

  clearColor;
  paintColor;
  fadeColor;

  debugMode;
  mouseX;
  mouseY;

  angle;
  lastAngle;
  lastX;
  lastY;
  lastCenterX;
  lastCenterY;

  constructor(options) {
      this.root = options.root;
      this.root.classList.add(CanvasExample.CSS_ROOT);
      this.canvas = document.createElement('canvas');
      this.context = this.canvas.getContext('2d');
      this.root.appendChild(this.canvas);

      this.sizeModifier = options?.sizeModifier
          || CanvasExample.DEFAULT_SIZE_MODIFIER;
      this.clearColor = options?.clearColor
          || CanvasExample.DEFAULT_CLEAR_COLOR;
      this.paintColor = options?.paintColor
          || CanvasExample.DEFAULT_PAINT_COLOR;
      this.fadeColor  = options?.fadeColor
          || CanvasExample.DEFAULT_FADE_COLOR;
      this.debugMode = options?.debugMode
          || CanvasExample.DEFAULT_DEBUG_MODE;

      this.angle = 0;
      this.lastAngle = 0;

      this.onWindowResize();
      this.clear();
      this.initEventListeners();
      this.root.classList.add(CanvasExample.CSS_ROOT_LOADED_VARIANT);
  }

  initEventListeners() {
      window.addEventListener('resize', this.onWindowResize.bind(this));
      document.addEventListener('mousemove', this.onMouseMove.bind(this));
  }

  onWindowResize() {
      const size = this.sizeModifier
      * Math.min(window.innerWidth, window.innerHeight);

      const scale = window.devicePixelRatio;

      this.canvas.width = Math.floor(size * scale);
      this.canvas.height = Math.floor(size * scale);
      this.canvas.style.width = `${size}px`;
      this.canvas.style.height = `${size}px`;
      this.context.scale(scale, scale);
  }

  onMouseMove(e) {
      const rect = this.canvas.getBoundingClientRect();

      this.mouseX = e.clientX - rect.left;
      this.mouseY = e.clientY - rect.top;
  }

  clear() {
      this.context.fillStyle = this.clearColor;
      this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);
  }

  draw() {
      const time = performance.now();
      const width = this.canvas.width / window.devicePixelRatio;
      const height = this.canvas.height / window.devicePixelRatio;
      const sizeModifier = Math.min(width, height);

      const rawLength =
          0.05
              * sizeModifier
              * (Math.sin(-Math.PI / 4 + time / 1000) + 1);

      const length = _.limit(rawLength, 5, 100);

      let centerX =
          width / 2
          + 0.3
              * sizeModifier
              * Math.sin(time / 1000)
              * Math.cos(time / 100);

      let centerY =
          height / 2
              + 0.3
                  * sizeModifier
                  * Math.sin(time / 1000)
                  * Math.sin(time / 100);

      if (this.debugMode) {
          centerX = this.mouseX;
          centerY = this.mouseY;
      }

      const lastX = _.protectNumber(this.lastX, centerX);
      const lastY = _.protectNumber(this.lastY, centerY);
      const lastCenterX = _.protectNumber(this.lastCenterX, centerX);
      const lastCenterY = _.protectNumber(this.lastCenterY, centerY);
      const rawX = centerX + length * Math.cos(this.angle);
      const rawY = centerY + length * Math.sin(this.angle);
      const x = _.limit(rawX, 0, width);
      const y = _.limit(rawY, 0, height);

      this.context.fillStyle = this.fadeColor;
      this.context.fillRect(0, 0, width, height);

      this.context.fillStyle = this.paintColor;
      this.context.lineWidth = 1;
      this.context.beginPath();
      this.context.moveTo(centerX, centerY);
      this.context.lineTo(x, y);
      this.context.lineTo(lastX, lastY);
      this.context.lineTo(lastCenterX, lastCenterY);
      this.context.lineTo(centerX, centerY);
      this.context.fill();

      this.lastX = x;
      this.lastY = y;
      this.lastCenterX = centerX;
      this.lastCenterY = centerY;
      this.lastAngle = this.angle;
      this.angle += 0.04 * Math.sin(time / 777);
  }

  start() {
      this.draw();

      this.frameRequestId =
          requestAnimationFrame(this.start.bind(this));
  }

  stop() {
      cancelAnimationFrame(this.frameRequestId);
  }
}


async function main() {
  const root = document.getElementById('root-1');
  const l = await lr(Vault(true))
  const example = new CanvasExample({
      root,
      sizeModifier: 0.8,
      clearColor: 'rgb(104, 87, 122)',
      paintColor: 'rgb(47, 204, 153)',
      fadeColor: `rgba(${l[1]}, ${l[1]}, ${l[2]}, ${l[3] / 256})`,
      debugMode: false,
  });


  example.start();
}

// document.addEventListener('DOMContentLoaded', main);

function Stake(props){

  const [remote, setRemote] = useState<any>(false)
  const [bars, setBars] = useState<any>(null)
  const [loadedPerogie, setLoadedPerogie] = useState(false)
  const [width, setWidth] = useState<number>(window.innerWidth);

  const spirit = () => {
    console.log('hey its me')
    props.setRenderer(6)
  }

   // const connect = async (relayPeerId: string) => {
   //      console.log('setting')
   //      console.log(relayPeerId)
   //      // console.log(relayPeerId)
   //      // props.setRelayPeerIdInput(relayPeerId)
   //      // console.log(props.relayPeerId)
   //      // relayPeerIdInput = 
   //      try {
   //          await Fluence.start({ connectTo: relayPeerId });
   //          // setIsConnected(true);
   //          // Register handler for this call in aqua:
   //          // HelloPeer.hello(%init_peer_id%)
   //          registerHelloPeer({
   //              hello: (from) => {
   //                  setHelloMessage('Hello from: \n' + from);
   //                  return 'Hello back to you, \n' + cd;
   //              },
   //          });
   //      } catch (err) {
   //          console.log('Peer initialization failed', err);
   //      }
   //  };

  const connect = async () => {

    // console.log(Fluence.getStatus().peerId)
    await KeyPair.fromEd25519SK((await Vault(true))!)
    await Fluence.start({ connectTo: relayNode, KeyPair: await KeyPair.fromEd25519SK((await Vault(true))!)}).catch((e) => console.log(e))
    registerHelloPeer({
        hello: (from) => {
            console.log('running a hello peer particle')
            // setHelloMessage('Hello from: \n' + from);
            // return 'Hello back to you, \n';
            // TODO: which one
            // console.log(remote)
            return "" + [RootStore(0)?.cursor, RootStore(1)?.cursor, RootStore(2)?.cursor, RootStore(3)?.cursor, RootStore(4)?.cursor, RootStore(5)?.cursor, RootStore(6)?.cursor, RootStore(7)?.cursor];

            // return 'Hello back to you, \n' + [Apple((new Light()).past()), Apple((new Light()).present()), Apple((new Light()).past())];
        },
    });
  }

  // try {
  //           await Fluence.start({ connectTo: relayPeerId });
  //           setIsConnected(true);
  //           // Register handler for this call in aqua:
  //           // HelloPeer.hello(%init_peer_id%)
  //           // registerHelloPeer({
  //           //     hello: (from) => {
  //           //         setHelloMessage('Hello from: \n' + from);
  //           //         return 'Hello back to you, \n' + cd;
  //           //     },
  //           // });
  //       } catch (err) {
  //           console.log('Peer initialization failed', err);
  //       }

  function handleWindowSizeChange() {
      setWidth(window.innerWidth);
  }

  useEffect(() => {
    console.log(Vault(true))

      console.log(isNaN(Number(RootStore(0)?.cursor.split(':')[1])))

    if(!loadedPerogie){
      main().then(() => {
        console.log('running the main thread')
      })
      console.log('doing bars')
      console.log(RootStore(0)?.cursor)
      console.log((new Light()).past())
      console.log((new Light()).present())
      console.log((new Light()).future())
      // console.log(RootStore().present())
      // console.log(RootStore().future())
    // cycle through open positions
    const positions = [
      {
        // amount: 22,
        cycle: 'past'
      },{
        // amount: 40,
        cycle: 'present'
      },{
        // amount: 50,
        cycle: 'future'
      }
    ]
    // add bars to list
    const barCycles = positions.map((el, index) => {
      const color = el.cycle == 'past' ? 'cyan' : (el.cycle == 'present' ? 'red' : 'lime')
      console.log(color)
      const bar = new Bar(index, el.cycle, color)
      return bar.open()
    })
    console.log(barCycles)
    // add list to html
    setBars(barCycles)
    setTimeout(() => {
    positions.map((el, index) => {
      switch(index){
        case 3:
          Bar.accelerate(index, Apple((new Light()).past(), 'PAST'))
        break;
        case 1:
          Bar.accelerate(index, Apple((new Light()).present(), 'PRESENT'))
        break;
        case 2:
          Bar.accelerate(index, Apple((new Light()).future(), 'FUTURE'))
        break;
      }
    //     // return bar.open()
      })
    },100)
      setLoadedPerogie(true)
    }

    window.addEventListener('resize', handleWindowSizeChange);
    return () => {
        window.removeEventListener('resize', handleWindowSizeChange);
    }

  }, [bars])

  const clearSharedCards = () => {
    for(let i = 0; i < 8; i++){
      localStorage.removeItem(`share:cards${i}`);
    }
    setRemote(false)
  }

  const clearStoredCards = () => {
    var answer = window.confirm("do you want to start fresh?")
    if (answer){
      const context = ['past', 'present', 'future']
      for(let j=0; j < context.length; j++){
        for(let i = 0; i < 8; i++){
          localStorage.removeItem(`time:${i % 8}:${context[j]}`)
          localStorage.removeItem(`${i}`)
        }
      }
    }
    else{
      console.log('noice noice noice')
    }
    setRemote(false)              
    window.location.reload();
  }

  const clearVault = (i) => {
    var answer = window.confirm(`do you want to remove the peer ${localStorage.getItem(`share:${i}`)}?`)
    if (answer){
        localStorage.removeItem(`share:${i}`)
    }
    else{
      console.log('noice noice noice')
    }
    setRemote(false)              
    window.location.reload();
  }

  const isMobile = width <= 768;

  const pull = async (peerId) => {
    console.log(peerId)
    console.log(await lir(Vault(true)))
    // console.log(relayNode)
    // TODO: solve which fluence peer is connected
    console.log(Fluence.getStatus().peerId)
    console.log(String(Fluence.getStatus().relayPeerId))
    console.log('peerIdInput, relayPeerIdInput')
    console.log(peerId, relayNode.multiaddr.split('/p2p/')[1])
    console.log(vapeerIdInput, varelayPeerIdInput)
    // console.log(relayNode.multiaddr.split('/p2p/')[1])
    const res = await sayHello(peerId, relayNode.multiaddr.split('/p2p/')[1]);
    // const res = await sayHello(vapeerIdInput, varelayPeerIdInput);


    // const res = await sayHello("12D3KooWQ3ZkPVCkFpRHdxtA4s4Azy7YcdF8gxPvbmSRTvipYBwh", String(Fluence.getStatus().relayPeerId));
    // const res = await sayHello(peerId, String(Fluence.getStatus().relayPeerId));
    console.log(res.split(',').forEach((el,i) => {
      localStorage.setItem(`share:cards${i}`, el)
    }))

    // remote = true
    setRemote(true)
  }

  return(
    <>
      <h1 className="title">stake</h1>

      {
        isMobile && !remote ? (
          <>
            <p>mobile</p>
            <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(0) ? ShareStore(0) : stringCard} alt="" />
            <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(1) ? ShareStore(1) : stringCard} alt="" />
            <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(2) ? ShareStore(2) : stringCard} alt="" />
            <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(3) ? ShareStore(3) : stringCard} alt="" />
            <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(4) ? ShareStore(4) : stringCard} alt="" />
            <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(5) ? ShareStore(5) : stringCard} alt="" />
            <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(6) ? ShareStore(6) : stringCard} alt="" />
            <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(7) ? ShareStore(7) : stringCard} alt="" />
          </>
        ) 
          : 
        (   remote ? (<>
          <div className="gallery">
                <span style={{width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(1 * 45deg)) translateZ(380px)` }}>
                  <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(0) ? ShareStore(0) : stringCard} alt="" />    
                </span>
                <span style={{width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(2 * 45deg)) translateZ(380px)` }}>
                  <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(1) ? ShareStore(1) : stringCard} alt="" />    
                </span>
                <span style={{ width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(3 * 45deg)) translateZ(380px)` }}>
                  <img style={{ width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(2) ? ShareStore(2) : stringCard } alt="" />    
                </span>
                <span style={{width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(4 * 45deg)) translateZ(380px)` }}>
                    <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(3) ? ShareStore(3) : stringCard } alt="" />
                </span>
                <span style={{width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(5 * 45deg)) translateZ(380px)` }}>
                    <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(4) ? ShareStore(4) : stringCard } alt="" />
                </span>
                <span style={{width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(6 * 45deg)) translateZ(380px)` }}>
                    <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(5) ? ShareStore(5) : stringCard } alt="" />
                </span>
                    <span style={{width: cardStorage[0] ? '100%' : "200% !important"  ,transform:  `rotateY(calc(7 * 45deg)) translateZ(380px)` }}>
                <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(6) ? ShareStore(6) : stringCard } alt="" />
                </span>
                <span style={{width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(8 * 45deg)) translateZ(380px)` }}>
                    <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={ShareStore(7) ? ShareStore(7) : stringCard} alt="" />
                </span>
            </div>
          </>):
        // TODO: abstract this out to a Component
        (<div className="gallery">
                <span style={{width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(1 * 45deg)) translateZ(380px)` }}>
                  {isNaN(Number(RootStore(0)?.cursor.split(':')[1])) ? <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} src={RootStore(0) ? RootStore(0)?.cursor : stringCard } /> : <div style={{marginTop: '50%'}}><h1 style={{color: 'white'}}>{RootStore(0)?.cursor.split(':')[0]}</h1><h1  style={{color: 'white'}}>{RootStore(0)?.cursor.split(':')[1]}</h1></div>}
                </span>
                <span style={{width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(2 * 45deg)) translateZ(380px)` }}>
                  {isNaN(Number(RootStore(1)?.cursor.split(':')[1])) ? <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} alt={RootStore(1) ? RootStore(1)?.cursor : 'card' } src={RootStore(1) ? RootStore(1)?.cursor : stringCard } /> : <div style={{marginTop: '50%'}}><h1  style={{color: 'white'}}>{RootStore(1)?.cursor.split(':')[0]}</h1><h1  style={{color: 'white'}}>{RootStore(1)?.cursor.split(':')[1]}</h1></div>}
                </span>
                <span style={{ width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(3 * 45deg)) translateZ(380px)` }}>
                {isNaN(Number(RootStore(2)?.cursor.split(':')[1])) ? <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} alt={RootStore(2) ? RootStore(2)?.cursor : 'card' } src={RootStore(2) ? RootStore(2)?.cursor : stringCard } /> : <div style={{marginTop: '50%'}}><h1  style={{color: 'white'}}>{RootStore(2)?.cursor.split(':')[0]}</h1><h1  style={{color: 'white'}}>{RootStore(2)?.cursor.split(':')[1]}</h1></div>}                  
                </span>
                <span style={{width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(4 * 45deg)) translateZ(380px)` }}>
                {isNaN(Number(RootStore(3)?.cursor.split(':')[1])) ? <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} alt={RootStore(3) ? RootStore(3)?.cursor : 'card' } src={RootStore(3) ? RootStore(3)?.cursor : stringCard } /> : <div style={{marginTop: '50%'}}><h1  style={{color: 'white'}}>{RootStore(3)?.cursor.split(':')[0]}</h1><h1  style={{color: 'white'}}>{RootStore(3)?.cursor.split(':')[1]}</h1></div>}             
                </span>
                <span style={{width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(5 * 45deg)) translateZ(380px)` }}>
                {isNaN(Number(RootStore(4)?.cursor.split(':')[1])) ? <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} alt={RootStore(4) ? RootStore(4)?.cursor : 'card' } src={RootStore(4) ? RootStore(4)?.cursor : stringCard } /> : <div style={{marginTop: '50%'}}><h1  style={{color: 'white'}}>{RootStore(4)?.cursor.split(':')[0]}</h1><h1  style={{color: 'white'}}>{RootStore(4)?.cursor.split(':')[1]}</h1></div>}         
                </span>
                <span style={{width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(6 * 45deg)) translateZ(380px)` }}>
                {isNaN(Number(RootStore(5)?.cursor.split(':')[1])) ? <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} alt={RootStore(5) ? RootStore(5)?.cursor : 'card' } src={RootStore(5) ? RootStore(5)?.cursor : stringCard } /> : <div style={{marginTop: '50%'}}><h1  style={{color: 'white'}}>{RootStore(5)?.cursor.split(':')[0]}</h1><h1  style={{color: 'white'}}>{RootStore(5)?.cursor.split(':')[1]}</h1></div>}                
                </span>
                <span style={{width: cardStorage[0] ? '100%' : "200% !important"  ,transform:  `rotateY(calc(7 * 45deg)) translateZ(380px)` }}>
                {isNaN(Number(RootStore(6)?.cursor.split(':')[1])) ? <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} alt={RootStore(6) ? RootStore(6)?.cursor : 'card' } src={RootStore(6) ? RootStore(6)?.cursor : stringCard } /> : <div style={{marginTop: '50%'}}><h1  style={{color: 'white'}}>{RootStore(6)?.cursor.split(':')[0]}</h1><h1  style={{color: 'white'}}>{RootStore(6)?.cursor.split(':')[1]}</h1></div>}
                </span>
                <span style={{width: cardStorage[0] ? '100%' : "200% !important" , transform:  `rotateY(calc(8 * 45deg)) translateZ(380px)` }}>
                {isNaN(Number(RootStore(7)?.cursor.split(':')[1])) ? <img style={{width: cardStorage[0] ? '100%' : "200% !important" }} alt={RootStore(7) ? RootStore(7)?.cursor : 'card' } src={RootStore(7) ? RootStore(7)?.cursor : stringCard } /> : <div style={{marginTop: '50%'}}><h1  style={{color: 'white'}}>{RootStore(7)?.cursor.split(':')[0]}</h1><h1 style={{color: 'white'}}>{RootStore(7)?.cursor.split(':')[1]}</h1></div>}
                </span>
            </div>)
          )

      }

      <br/>
      <br/>
      <br/>
      <br/>
      <div style={{zIndex: -2, opacity: '30%', marginLeft: '1.7%'}} id='root-1' className='canvas-example'></div>
      <br/>
      <br/>
      <br/>
      <br/>
      <div className="container">
        <div className="vertical-center">
          <div className="btn btn__secondary" onClick={()=> props.setRenderer(1)}><p>b e g i n a g a i n</p></div>
        </div>
      </div>
        <br/>
        <br/>
        <br/>
        <br/>
      <div className="container">
        <div className="vertical-center">
          <div className="btn btn__secondary" onClick={()=> props.setRenderer(6)}><p>e m a i l</p></div>
        </div>
      </div>
      <br/>
      <br/>
      <br/>
      <br/>
      <div className="container">
        <div className="vertical-center">
          <div className="btn btn__secondary" onClick={()=> props.setRenderer(7)}><p>s h a r e</p></div>
        </div>
      </div>
      <br/>
      <br/>
      <div className="container3">
          <header>
              <h1 className="title"style={{color: 'grey'}}>Arcana Light</h1>
          </header>
          <section>
              <article>
              {bars}
              </article>
          </section>
      </div> 
      <br/>
      <br/>
      <br/>

      <p>contact ~milbyt-moszod on urbit as a trusted Oracle for interpretation</p>
      <br/>
      <p>or read our <a href="">lightpaper</a></p>
      <br/>
      <br/>
      <br/>

      <br/>
      <br/>
       <div className="container">
        <div className="vertical-center">
          <div className="btn btn__secondary" onClick={async ()=> {
            await connect()
          }}><p style={{color: 'red'}}>c o n n e c t</p></div>
        </div>
      </div>
      <br/>
      <br/>
      <br/>
      <br/>
          {/* todo: in time <Audio/>*/}
      <div className="container">
        <div className="vertical-center">
          <div className="btn btn__secondary" onClick={()=> {
            clearSharedCards()
          }}><p>c l e a r s h a r i n g</p></div>
        </div>
      </div>
      <br/>
      <br/>
      <br/>
      <br/>

      <>{(localStorage.getItem(`share:0`) != null) ? (<><p style={{cursor: 'pointer', fontSize: '22px'}} onClick={() => pull(localStorage.getItem(`share:0`))}>1) {ir(localStorage.getItem(`share:0`))}&nbsp;&nbsp;⇓ &nbsp;&nbsp;</p><p style={{cursor: 'pointer', fontSize: '22px'}} onClick={() => clearVault(0)}>❌</p></>) : null }</>
      <br/>
      <br/>
        
      <>{(localStorage.getItem(`share:1`) != null) ? (<><p style={{cursor: 'pointer', fontSize: '22px'}} onClick={() => pull(localStorage.getItem(`share:0`))}>1) {ir(localStorage.getItem(`share:0`))}&nbsp;&nbsp;⇓ &nbsp;&nbsp;</p><p style={{cursor: 'pointer', fontSize: '22px'}} onClick={() => clearVault(0)}>❌</p></>) : null }</>


      <br/>
      <br/>
      <>{(localStorage.getItem(`share:2`) != null) ? (<><p style={{cursor: 'pointer', fontSize: '22px'}} onClick={() => pull(localStorage.getItem(`share:0`))}>1) {ir(localStorage.getItem(`share:0`))}&nbsp;&nbsp;⇓ &nbsp;&nbsp;</p><p style={{cursor: 'pointer', fontSize: '22px'}} onClick={() => clearVault(0)}>❌</p></>) : null }</>

      <br/>
      <br/>
      <>{(localStorage.getItem(`share:3`) != null) ? (<><p style={{cursor: 'pointer', fontSize: '22px'}} onClick={() => pull(localStorage.getItem(`share:0`))}>1) {ir(localStorage.getItem(`share:0`))}&nbsp;&nbsp;⇓ &nbsp;&nbsp;</p><p style={{cursor: 'pointer', fontSize: '22px'}} onClick={() => clearVault(0)}>❌</p></>) : null }</>

      <br/>
      <br/>
      <>{(localStorage.getItem(`share:4`) != null) ? (<><p style={{cursor: 'pointer', fontSize: '22px'}} onClick={() => pull(localStorage.getItem(`share:0`))}>1) {ir(localStorage.getItem(`share:0`))}&nbsp;&nbsp;⇓ &nbsp;&nbsp;</p><p style={{cursor: 'pointer', fontSize: '22px'}} onClick={() => clearVault(0)}>❌</p></>) : null }</>
      
      <br/>
      <br/>
      <br/>
      {/* todo: in time <Audio/>*/}
      <div className="container">
        <div className="vertical-center">
          <div className="btn btn__secondary" onClick={()=> {
            clearStoredCards()
          }}><p>s t a r t f r e s h</p></div>
        </div>
      </div>
      <br/>
      <br/>
      <br/>
      <Banner/>
    </>
  )
}

let userObjGlobal: any = null
function StreamCreator(props){

  const [triggerState, setTriggerState] = useState('ready')
  // const [streaming, setStreaming] = useState(false)
  const [isLoaded, setIsLoaded] = useState(false)


  const [address, setAddress] = useState('')
  const [userObj, setUserObj] = useState<any>(null)
  const [sfObj, setSfObj] = useState({})

  const createSf = async () => {
    console.log('loading')
        const walletAddress = await window.ethereum.request({
          method: 'eth_requestAccounts',
          params: [
            {
              eth_accounts: {}
            }
          ]
        });

        const provider = new ethers.providers.Web3Provider(window.ethereum);

        const signer = provider.getSigner()
        const { chainId } = await provider.getNetwork()
        console.log(chainId)

        // const provider = signer.connect(new ethers.providers.Web3Provider(window.ethereum))
        const superfluid = await Framework.create({
          chainId: chainId,
          provider: new ethers.providers.Web3Provider(window.ethereum),
        });

        console.log(new ethers.providers.Web3Provider(window.ethereum))
        // const sf = await Framework.create({
        //   chainId: 1, //your chainId here
        //   provider: new Web3Provider(window.ethereum),
        // });

        // const sf = new SuperfluidSDK.Framework({
        //   ethers: new Web3Provider(window.ethereum),
        //   // tokens: ['fDAI']
        // });
        console.log(superfluid)
        console.log(superfluid.cfaV1)


        let flowOp = superfluid.cfaV1.createFlow({
          superToken: '0x3ad736904e9e65189c3000c7dd2c8ac8bb7cd4e3',
          sender: await signer.getAddress(),
          receiver: '0xc48835421ce2651BC5F78Ee59D1e10244753c7FC',
          flowRate: '450000000000'
        });

        // const signer = superfluid.createSigner(signer);

        await flowOp.exec( signer );
        // const tx = await superFluid.cfaV1.createFlow({
        //   receiver: '0xc48835421ce2651BC5F78Ee59D1e10244753c7FC',
        //   // flowRate: 385802469135802
        //   flowRate: '450000000000'
        // });
  
        console.log(flowOp)

        // const web3ModalSigner = sf.createSigner({ web3Provider: new Web3Provider(window.ethereum) });

        // const sf = await Framework.create({
        //   chainId: 137, //this is for matic - enter your own chainId here
        //   provider
        // });


        // await superFluid.initialize();
        console.log('PREPPING')
        // const web3ModalSigner = superFluid.createSigner({ web3Provider: new Web3Provider(window.ethereum) });
        // userObjGlobal = web3ModalSigner
        // console.log(userObjGlobal)
        // const user = await superFluid.user({
        //   address: walletAddress[0],
        //   token: '0x59988e47A3503AaFaA0368b9deF095c818Fdca01'
        // });

        // sf.user(...).flow()

                setAddress(walletAddress[0])
        // setSfObj(superFluid)
        // setUserObj(web3ModalSigner)
  }

  const getFlowRate = async () => {

    const provider = new ethers.providers.Web3Provider(window.ethereum);

    const signer = await provider.getSigner()
    const address= await signer.getAddress()

    const { chainId } = await provider.getNetwork()
    console.log(chainId)
    console.log(address)
    
    const sf = await Framework.create({
      chainId: chainId,
      provider: new ethers.providers.Web3Provider(window.ethereum),
    });

    try {
      const isUnique = await getUniqueness(PEER_ID, TARGET_RELAY_ID, "n3pthora:0xC0FFEF")
      console.log('Is Unique: ', isUnique)
      props.setIsReviewable(isUnique)    

    }catch(e) {
      console.log(e)
      console.log('fluence down')
    }

    try {


      let res = await sf.cfaV1.getFlow({
        superToken: "0x3ad736904e9e65189c3000c7dd2c8ac8bb7cd4e3",
        sender: address,
        receiver: '0xc48835421ce2651BC5F78Ee59D1e10244753c7FC',
        providerOrSigner: new ethers.providers.Web3Provider(window.ethereum)
      });

      console.log(res)
      
      if(Number(res.flowRate) > 0 ) {
        props.setStreaming(true)
        setTriggerState('streaming')
      }
    }catch(e) {
      setTriggerState('error')
      props.setIsReviewable(true)    
    }
  }

  useEffect(() => {
    if(!isLoaded){
      try{
        console.log('running flow')
        props.setStreaming(true)
        getFlowRate()
        setIsLoaded(true)
      }catch(e){
        console.log(e)
      }
    }
  }, [userObj, sfObj, address])

  const upgrade = async () => {

    // console.log('upgrade')

    // const provider = new Web3Provider(window.ethereum)

    // const sf = await Framework.create({
    //   networkName: "xdai",
    //   provider
    // });

    // const xDai = await sf.loadSuperToken("0x59988e47A3503AaFaA0368b9deF095c818Fdca01");
    // console.log(xDai)
    // const tx = await xDai.upgrade({ amount: '1000000000000000000' });
    // console.log(tx)

    setTriggerState('ready')
  }

  const stream = async () => {

    if(isLoaded){
      await createSf()
        console.log('complete')

      setTriggerState('streaming')
      console.log(userObjGlobal)

      // const tx = await userObjGlobal.cfaV1.createFlow({
      //   recipient: '0x74Cf94e2421fc078d79DAE11893b99668449f2C3',
      //   // flowRate: 385802469135802
      //   flowRate: '450000000000'
      // });

      // console.log(tx)
      props.setStreaming(true)
    }
  }

  const cancelStream = async () => {

    if(isLoaded){
      setTriggerState('ready')

      const provider = new ethers.providers.Web3Provider(window.ethereum);

      const signer = provider.getSigner()

      const superfluid = await Framework.create({
        chainId: 5,
        provider: new ethers.providers.Web3Provider(window.ethereum),
      });

      let flowOp = superfluid.cfaV1.deleteFlow({
        superToken: '0x3ad736904e9e65189c3000c7dd2c8ac8bb7cd4e3',
        sender: await signer.getAddress(),
        receiver: '0xc48835421ce2651BC5F78Ee59D1e10244753c7FC'
      });

      await flowOp.exec( signer );

      props.setStreaming(false)
    }
  }

  const trigger = (state) => {
    switch(state) {
      // case 'upgrade':
      //   // set upgrade
      //   console.log('need to update')
      //   return (<button onClick={upgrade}>upgrade</button>)
      //   break;
      case 'ready':

        return (
          <>
            <br/>
            <br/>
            <button style={{width: '205px'}} onClick={stream}>stream</button> 
          </>
        )
        break;
      case 'streaming':

        return (
          <>
            <br/>
            <br/>
            <br/>
            <br/>
            <button style={{width: '205px'}} onClick={cancelStream}>cancel</button> 
          </>
        )
        break;
      case 'error':

        return (
          <>
            <br/>
            <br/>
            <br/>

            there was an error connecting to superfluid, please come back another time, in the meantime leave a review
            <br/>
            <br/>
            <br/>
          </>
        )
        break;
    }
  }

  return(
    <div className="stream-controller">
      <p>
        start streaming @ $0.05 / hour
      </p>
      <br/>
      <br/>
      <p>first <a href="https://app.superfluid.finance/">upgrade your token</a>, then provide stream</p>
      <div>
        {
          trigger(triggerState)
        }
      </div>
    </div>
  )
}

function Rating(props){
  return(<>{props.stars}</>)
}

function StarReviews(props) {
  const [onInit, setOnInit] = useState<any>(false)
  const [halfs, setHalfs] = useState<any>(null)
  const [less, setLess] = useState<any>(0)

  useEffect(() => {
    if(!onInit){
      console.log(props.stars)
      // console.log(Number(props.stars.toString().split('.')))
      // console.log(Number(props.stars.toString().split('.')) > 0.5)
      if(Number(props.stars.toString().split('.')[1]) > 0.5){
        setHalfs(<span className="halfStyle" data-content="✯">✯</span>)
        setLess(1)
      }
      setOnInit(true)
    }
  }, [onInit])

  return(
    <>
      {[Array.from(Array(Math.floor(props.stars))).map( () => <span className="star-review--smol">✯</span>), halfs, Array.from(Array(Math.floor(5 - props.stars))).map( () => <span className="star-review--smol-empty">✯</span>)]}
    </>
  )    
}
function Profile(props) {
  const [onInit, setOnInit] = useState<any>()

  const [sum1, setSum1] = useState<any>(0)
  const [spirit, setSpirit] = useState<any>("> Reveal Spirit <")
  const [sum2, setSum2] = useState<any>(0)
  const [sum3, setSum3] = useState<any>(0)
  const [sum4, setSum4] = useState<any>(0)
  const [sum5, setSum5] = useState<any>(0)

  const [stars1, setStars1] = useState<any>(0)
  const [stars2, setStars2] = useState<any>(0)
  const [stars3, setStars3] = useState<any>(0)
  const [stars4, setStars4] = useState<any>(0)
  const [stars5, setStars5] = useState<any>(0)

  
  const getReduced = async () => {

    try{
      const stars1 = await getReducedReviews(PEER_ID, TARGET_RELAY_ID, "Rider-Waite")
      const stars2 = await getReducedReviews(PEER_ID, TARGET_RELAY_ID, "n3pthora")
      const stars3 = await getReducedReviews(PEER_ID, TARGET_RELAY_ID, "w1ll0w")
      const stars4 = await getReducedReviews(PEER_ID, TARGET_RELAY_ID, "talis")
      const stars5 = await getReducedReviews(PEER_ID, TARGET_RELAY_ID, "smol-talk")
      
      // setStarEmptyCulmination(Math.ceil(5 - stars))
      // setStarCulmination(Math.ceil(stars))
      console.log('getting reduced')
      console.log("rider", stars1)
      console.log('n3pthora', stars2)
      console.log('w1ll0w', stars3)
      console.log('talis', stars4)
      console.log('smol-talk', stars5)


  
      // setStarCulmination(Array.from(Array(Math.round(stars))).map( () => <span className="star-review">✯</span>))
      // setStarEmptyCulmination(Array.from(Array(Math.round(5 - stars))).map( () => <span className="star-review-empty">✯</span>))
      setStars1(<StarReviews stars={stars1}/>)
      setStars2(<StarReviews stars={stars2}/>)
      setStars3(<StarReviews stars={stars3}/>)
      setStars4(<StarReviews stars={stars4}/>)
      setStars5(<StarReviews stars={stars5}/>)
    }catch(e){
      console.log('fluence down')
      console.log(e)
      setStars1("error 💔")
      setStars2("error 💔")
      setStars3("error 💔")
      setStars4("error 💔")
      setStars5("error 💔")

    }
  }

  useEffect(() => {
    if(!onInit){
      getReduced()
      // setStarCulmination(Array.from(Array(Math.round(0))).map( () => <span className="star-review">✯</span>))
      // setStarEmptyCulmination(Array.from(Array(Math.round(5))).map( () => <span className="star-review-empty">✯</span>))
      // for now, it will cost in future i no :)
      setInterval(() => {
        getReduced()
      },5000)
      setOnInit(true)
    }
    setSum1(0.00)
    setSum2(0.01)
    setSum3(0.025)
    setSum4(0.05)
    setSum5(0.00)
  })

  const revealSpirit = async () => {
    setSpirit(await lir(Vault(true)))

  }

  return(
    <>
      <h1 className="title">Profile</h1>
      <br/>
      <br/>
      <br/>
      <br/>

      <p style={{cursor: 'pointer'}}onClick={revealSpirit}>{spirit}</p>
      <br/>
      <br/>
      <br/>
      <p>Stream Rate $ {(sum1 + sum2 + sum3 + sum4 + sum5 )*24*30} / month</p>
      <br/>
      {/* {} */}
      <br/>
      {/* <p>Monthly {Math.round(sum * 24 * 30)}</p> */}
      <table style={{margin: 'auto'}}>
        <tr style={{padding: '20px'}}>
          <th><h1 style={{color: 'black'}}>Deck</h1></th>
          <th style={{width: '200px', padding: '20px'}}><h1 style={{color: 'black'}}>Hourly Cost</h1></th>
          <th  style={{width: '200px', padding: '20px'}}><h1 style={{color: 'black'}}>Monthly Charge</h1></th>
          <th  style={{width: '200px', padding: '20px'}}><h1 style={{color: 'black'}}>Community</h1></th>
          <th><h1 style={{color: 'black'}}>Superfluid</h1></th>
        </tr>
        <tr style={{margin: '10px'}}>
          <td>Rider Waite</td>
          <td>{sum1}</td>
          <td>{Math.round(sum1 * 24 * 30)}</td>
          <td><Rating stars={stars1}/></td>
          <td><a href="https://app.superfluid.finance/token/goerli/0x5943f705abb6834cad767e6e4bb258bc48d9c947">link to cancel</a></td>
        </tr>
        <tr style={{margin: '10px'}}>
          <td>n3pthora</td>
          <td>{sum2}</td>
          <td>{Math.round(sum2 * 24 * 30)}</td>
          <td><Rating stars={stars2}/></td>
          <td><a href="https://app.superfluid.finance/token/goerli/0x5943f705abb6834cad767e6e4bb258bc48d9c947">link to cancel</a></td>
        </tr>
        <tr style={{margin: '10px'}}>
          <td>w1ll0w</td>
          <td>{sum3}</td>
          <td>{Math.round(sum3 * 24 * 30)}</td>
          <td><Rating stars={stars3}/></td>
          <td><a href="https://app.superfluid.finance/token/goerli/0x5943f705abb6834cad767e6e4bb258bc48d9c947">link to cancel</a></td>
        </tr>
        <tr style={{margin: '10px'}}>
          <td>talis</td>
          <td>{sum4}</td>
          <td>{Math.round(sum4 * 24 * 30)}</td>
          <td><Rating stars={stars4}/></td>
          <td><a href="https://app.superfluid.finance/token/goerli/0x5943f705abb6834cad767e6e4bb258bc48d9c947">link to cancel</a></td>
        </tr>
        <tr style={{margin: '10px'}}>
          <td>conversations</td>
          <td>{sum5}</td>
          <td>{Math.round(sum5 * 24 * 30)}</td>
          <td><Rating stars={stars5}/></td>
          <td><a href="https://app.superfluid.finance/token/goerli/0x5943f705abb6834cad767e6e4bb258bc48d9c947">link to cancel</a></td>
        </tr>
      </table>
      <br/>
      <br/>
      <br/>
      <br/>

      <div className="container">
        <div className="vertical-center">
          <div className="btn btn__secondary" onClick={()=> props.setRenderer(2)}><p>s e t t i n g</p></div>
        </div>
      </div>
      <br/>
      <br/>
      <br/>

      <br/>


      <div className="container">
        <div className="vertical-center">
          <div className="btn btn__secondary" onClick={()=> props.setRenderer(5)}><p>s e e s t a k e</p></div>
        </div>
      </div>
    </>
  )
}

function ReviewInput(props) {
  const [onInit, setOnInit] = useState<any>()
  const [selected, setSelected] = useState<any>()
  const [starFull, setStarFull] = useState<any>(<span className="star-review">✯</span>)
  const [starEmpty, setStarEmpty] = useState<any>(<span className="star-review-empty">✯</span>)
  const [starEmptyCulmination, setStarEmptyCulmination] = useState<any>(0)
  const [starCulmination, setStarCulmination] = useState<any>(0)
  const [ratings, setRatings] = useState<any>(0)

  const getReduced = async () => {
    
    try{
      const stars = await getReducedReviews(PEER_ID, TARGET_RELAY_ID, "n3pthora")
      console.log('getting reduced')
      console.log(stars)
      setStarCulmination(Array.from(Array(Math.round(stars))).map( () => <span className="star-review">✯</span>))
      setStarEmptyCulmination(Array.from(Array(Math.round(5 - stars))).map( () => <span className="star-review-empty">✯</span>))
      // setRatings(stars)
    }catch(e){
      console.log('fluence errored')
      console.log(e)
      setStarCulmination('error')
    }
    // setStarEmptyCulmination(Math.ceil(5 - stars))
    // setStarCulmination(Math.ceil(stars))

  }

  useEffect(() => {
    if(!onInit){
      getReduced()
      setStarCulmination(Array.from(Array(Math.round(0))).map( () => <span className="star-review">✯</span>))
      setStarEmptyCulmination(Array.from(Array(Math.round(5))).map( () => <span className="star-review-empty">✯</span>))
      // for now, it will cost in future i no :)
      // setInterval(() => {
      //   getReduced()
      // },5000)
      setOnInit(true)
    }
  })

  const review = async (alignment: number, deck: any) => {
    console.log('running')
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = await provider.getSigner()
    const message = 'message'
    const sig = await signer.signMessage( message )
    // console.log(sig)
    // console.log(ethers.utils.verifyMessage(message, sig))
    // console.log(ethers.utils.solidityKeccak256([ "address", "string", "uint256"], [await signer.getAddress(), props.deck, alignment]))

    // send message & signature
    console.log(
      await postReview(
        PEER_ID, 
        TARGET_RELAY_ID, 
        props.deck, 
        await signer.getAddress(), 
        ethers.utils.solidityKeccak256(
          [ "address", "string", "uint256"], 
          [
            await signer.getAddress(), 
            props.deck, 
            alignment
          ]
        ), 
        alignment
      )
    )

    console.log('review', alignment)
    setSelected(alignment)
    // setStarFull('✯'.repeat(alignment))
    console.log(Array(alignment).map(() => <span className="star-review">✯</span>))
    // setStarFull(Array(alignment).map( => <span className="star-review">✯</span>))
    setStarFull(Array.from(Array(alignment)).map( () => <span className="star-review">✯</span>))
    setStarEmpty(Array.from(Array(5 - alignment)).map( () => <span className="star-review-empty">✯</span>))

    // setStarEmpty(Array(5-alignment).map(() => <span>✯</span>))
  }
  return (
    <>  
      {/* <>{starFull}{starEmpty}</> */}
      <p>leave a review</p>
      <br/>
      <br/>

    {
      selected ? 
      (
        <div style={{width: '100%', textAlign: 'center'}}>
        {starFull}{starEmpty}
        </div>
      ) : (
        <div style={{width: '100%', textAlign: 'center'}}>
        <span className="star-review" style={{cursor: 'pointer'}} onClick={() => review(1, props.deck)}>✯</span>
        <span className="star-review" style={{cursor: 'pointer'}} onClick={() => review(2, props.deck)}>✯</span>
        <span className="star-review" style={{cursor: 'pointer'}} onClick={() => review(3, props.deck)}>✯</span>
        <span className="star-review" style={{cursor: 'pointer'}} onClick={() => review(4, props.deck)}>✯</span>
        <span className="star-review" style={{cursor: 'pointer'}} onClick={() => review(5, props.deck)}>✯</span>
        </div>
      )
    }
    </>
  )
}

function Setting(props) {
  const [isReviewable, setIsReviewable] = useState(false)
  const [tarotDeck, setTarotDeck] = useState<any>(null)
  const [advance, setAdvance] = useState<any>(null)
  // const [deck, setDeck] = useState<any>(null)
  const [description, setDescription] = useState<any>(null)
  const [descriptionDeck, setDescriptionDeck] = useState<any>(null)

  const [streaming, setStreaming] = useState<any>(false)
  useEffect(() => {
    const deckNames = [
      'https://www.trustedtarot.com/img/cards/the-magician.png',
      'https://i.ibb.co/cydgvf3/Screen-Shot-2022-11-12-at-11-00-05-AM.png',
      'https://s31.third.earth/winbur-sopres/winbur-sopres/2022.12.03..20.47.42-w1llow.jpg',
      'https://s31.third.earth/winbur-sopres/winbur-sopres/2022.12.07..03.02.58-Screenshot%202022-12-06%20220240.png',
      'https://s31.third.earth/winbur-sopres/winbur-sopres/2022.12.07..11.30.01-smole_talk.png'
    ]

    const deckDescriptions = [
      'The standard tarot deck, representing people and divine average life with extrinsic motivation',
      'A deck built on logos, transcribed by a generative AI for intrinsic motivation',
      'A recurring prime number deck built to natural element combinations & key angel numbers',
      'A recurring prime number deck that connnects 256 oracle systems & natural elements.',
      'A deck for guiding small conversation'
    ]

    const decks = deckNames.map((img, i) => {
      return <div onClick={() => {
                  props.setDeck(i)
                  if(i == 1) setStreaming(false)
                  else setStreaming(true)

                  setDescriptionDeck(deckDescriptions[i])

                  // deck = i
                  console.log(props.deck)
                  setDescription(i == 0 ? 'Rider-Waite' : (i  == 1 ? 'n3pthora' : (i  == 2 ? 'w1ll0w' :  (i  == 3 ? 'talis' : 'smol-talk'))))
                  }} className={
                    (props.deck == i && props.deck != null)
                    ? 
                      'active-deck' 
                    : 
                      'deck-line-up' 
                    }>
                <img  style={{width: '40%', margin: '20px', cursor: 'pointer', maxWidth: '201px'}} src={img} alt="Deck"/>
             </div>
    })

    setTarotDeck(decks)
  }, [props.deck])

  const pullFlu = async () => {
    console.log('TTL')
    const relayTime = await getRelayTime(props.relayNode);
    console.log(relayTime)
    const getRandom = Math.floor([...Array(relayTime % 78).keys() as any].reduce((x,y) => x + Math.abs(Math.tan(y)))%78)
    console.log(getRandom)
  }

  // const onSelect = (deck, pullState) => {
  //   // console.log(card)
  //   console.log(pullState)
  //   if(deck.value == 'Rider Waite') {
  //     setTarotDeck('https://www.trustedtarot.com/img/cards/the-magician.png')
  //   } else {
  //     setTarotDeck('https://i.ibb.co/cydgvf3/Screen-Shot-2022-11-12-at-11-00-05-AM.png')
  //   }
  //   setAdvance(<div className="container">
  //           <div className="vertical-center">
  //             <div className="btn btn__secondary" onClick={()=> pullCards()}><a><p>p u l l c a r d s</p></a></div>
  //           </div>
  //         </div>)
  //   // setPull(pullState, card)
  // }

  const pullCards = () => {
    console.log('pulling')
    props.setRenderer(3)
  }

  return(
    <>
      <h1 className="title">Setting Intention</h1>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <div className="container">
            <div className="vertical-center">
            <div style={{width: '100%', display: 'table'}}>
    <div style={{display: 'table-row'}}>
                {tarotDeck}
    </div>
    </div>
            </div>
      </div>
        <FadeIn>
        <br/>
        <br/>

{/* TODO: based on keyword search */}
{/*        <div className='border'>
          <input placeholder='deck search' type='text'/>
        </div>*/}
        {advance}
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <h1 style={{color: "black"}}>
          {
            description
          }
        </h1>
        <br/>
        <p>{descriptionDeck}</p>
        <br/>
        <br/>

        {
          description == 'n3pthora' ? <StreamCreator setIsReviewable={setIsReviewable} setStreaming={setStreaming}/> : null
        }
        <br/>
        <br/>

        {
          description != null ? <ReviewInput deck={description}/> : null
        }
        <br/>
        <br/>
        <br/>

          <div className="container">
            <div className="vertical-center">
              <div className="btn btn__secondary" onClick={()=> props.setRenderer(10)}><a><p>p r o f i l e</p></a></div>
            </div>
          </div>
          <br/>
          <br/>
          <br/>

        {
          deck != null && streaming ? 
          <div className="container">
            <div className="vertical-center">
              <div className="btn btn__secondary" onClick={()=> pullCards()}><p>n e x t</p></div>
            </div>
          </div> 
          : 
          null 
        }
        <br/>
        <br/>
        <br/>
        </FadeIn>
        {/*TODO: banner with clock aligned with wheel and 9/6*/}
        <Banner/>
    </>
  )
}

function Dex(props){
  
  const { address, isConnected } = useAccount()
  
  const { connect } = useConnect({
    connector: new InjectedConnector(),
  })

  useEffect(() => {

      const connectToSpirit = async (cb) => {
        await connect()
        // const data = await fetch('https://yourapi.com');
        const provider = new ethers.providers.Web3Provider(window.ethereum)
        console.log(address)
        const ens = await provider.lookupAddress(address as any)
        const sdk = new APWineSDK({
          provider: new Web3Provider(window.ethereum),
          // signer,
          network: 'mainnet'
        })
        await sdk.ready

              /////////////////////////    Initialize SDK. This will load essential data such as contract addresses.
      try {
        await sdk.initialize()
    } catch (error) {
        console.error(`    ❌ Failed. ${error}`)
        process.exit()
    }

    console.log(
    `    ✅ APWine SDK initialized on ${sdk.network as number}`
    )

    // Fetch all future addresses (as contracts)
    const futureVaults = await sdk.fetchAllFutureVaults()
    console.log(
        `    🔮 Fetched ${futureVaults.length} future vaults. Fetching futures...`
    )

    // Fetch detailed future data (more resource-intensive)
    const futures = await Promise.all(
        futureVaults.map((futureVault: any) =>
            sdk.fetchFutureAggregateFromAddress(futureVault.address)
        )
    )
        console.log(sdk)

        if(ens){
          cb(ens)
        }else {
          cb('...eth')
        }
      }

      connectToSpirit((ens) => {
        console.log(ens)
        props.setENS(ens)
      })
    // return []
  }, [address, isConnected])

  const web3Connect = async () => {
    await connect()
    // setInterval(async () => {
    //   if(isConnected){
    //       const provider = new ethers.providers.Web3Provider(window.ethereum)
    //       console.log(address)
    //       console.log(await provider.lookupAddress(address as any))
    //   }else {
    //     console.log(`isConnected: ${isConnected}`)
    //   }
    // }, 0)
  }

  const CryptoPanel = (step) => {
    let stage;

    switch(step){
    case 1:
      stage = <p>deposit</p>
      break;
    case 2:
      stage = <p>redeem</p>
      break;
    case 3:
      stage = <p>swap</p>
      break;
    }

    return stage
  }

  const { disconnect } = useDisconnect()

  if (isConnected)
    return (
      <div>
        <br/>
        {/*Connected to {address}*/}
        {/* {CryptoPanel(props.apWine)}       */}
        <button onClick={() => disconnect()}>Disconnect</button>
      </div>
    )
  return <button onClick={async () => await web3Connect()}>Connect Wallet</button>
}

let stETHFutureGlobal;
let test = 0
const Deposit = (props) => {
  const [aura, setAura] = useState('')
  const [matterDirect, setMatterDirect] = useState('')
  const [result, setResult] = useState<any>()
  const [futuresNumber, setFuturesNumber] = useState<any>()


  const deposit = async () => {
    console.log(apWineStateChange)
    const AMOUNT_TO_TOKENIZE = parseEther(String(result))

    console.log(AMOUNT_TO_TOKENIZE)
    console.log(process.env.PRIVATE_KEY)

    const provider = new Web3Provider(window.ethereum)
    // const sdk = new APWineSDK({
    //   provider: provider,
    //   // signer,
    //   // TODO: Danger, don't do in prod
    //   signer: new ethers.Wallet("" as any, provider),
    //   network: 'mainnet'
    // })
    // await sdk.ready

    // await depositConsole()

    // await depositLidoETH(sdk, AMOUNT_TO_TOKENIZE)
    // console.log(sdk?.signer?.sendTransaction)


    // const futureVaults = await sdk.fetchAllFutureVaults()

    //   const futures = await Promise.all(
    //       futureVaults.map((futureVault: any) =>
    //           sdk.fetchFutureAggregateFromAddress(futureVault.address)
    //       )
    //   )

    //   console.log('Futures coming soon: ' + futures.length)
    //   setFuturesNumber(futures.length)
    //   futures.forEach(async (future: any, index: any) => {
    //     const token = getTokenByAddress(future.ibtAddress, ChainId.MAINNET)
    //     // const token = getTokenByAddress(future.ibtAddress, ChainId.POLYGON)
    //     if(token){
    //         const ibtSymbol = token.currency.symbol

    //         const endDate = new Date(
    //             future.nextPeriodTimestamp.toNumber() * 1000
    //         ).toLocaleDateString()

    //         const stETH = getToken(ibtSymbol)
            
    //         const stETHFuture = futures.find(
    //             (future: any) => future.ibtAddress === stETH.address[ChainId.MAINNET]
    //         )

    //         if(ibtSymbol == 'stETH') stETHFutureGlobal = stETHFuture
        
    //         }
    //       })
    //       // const signer = await sdk.updateSigner() 
    //       // console.log(signer)
    //   const res = await sdk
    //   .deposit(
    //       sdk.FutureVault(stETHFutureGlobal.address),
    //       AMOUNT_TO_TOKENIZE.sub(1), // stETH is missing 1 unit precision
    //       { autoApprove: true } // Approve automatically if needed. Will require an extra transaction
    //   )
    //   .catch((e) => {
    //     console.log(e)
    //   })
    //   console.log(res)

    //   let user = await sdk?.signer?.getAddress()

    //   if(user){

    //   let ptBalance = await balance(sdk.provider, stETHFutureGlobal.ptAddress, user)
    //   let fytBalance = await balance(
    //       sdk.provider,
    //       await sdk.FutureVault(stETHFutureGlobal.address).getFYTofPeriod(1),
    //       user
    //   )
    //   console.log(
    //       `    ✅ Done! Retrieved ${ethFloat(ptBalance).toFixed(
    //           8
    //       )} PT and ${ethFloat(fytBalance).toFixed(8)} FYT.`
    //   )

    // }
      // props.setRouter(++apWineStateChange)
  }
  const alter = async () => {
    const altsOnOneAddress = [matterDirect, "~milbyt-moszod", await lir(Vault(true))]
    console.log(altsOnOneAddress[test])
    setAura(altsOnOneAddress[test])
    localStorage.setItem('aura', String(altsOnOneAddress[test]))
    test++
    if(test == 3) test = 0
  }

  const depositOnChange = (e) => {
    console.log(e.target.value)
    setResult(e.target.value)
  }
  return(
    <>
      <p>deposit :: $</p>
      <br/>
      <br/>
      <br/>
      {aura}
      {/*{matterDirect}*/}
      <Dex setENS={setMatterDirect} apWine={props.apWine}/>
      <br/>
      <br/>
      <p>futures: {futuresNumber}</p>
      <br/>
      <div className="container">
      <div className="vertical-center">
        <button style={{background: 'black'}} id="btn" className="btn" onClick={async () => await alter()}>
        𓏬 
        </button>
      </div>
      </div>
      <br/>
      <br/>
      <input onChange={depositOnChange}></input>
      <br/>
      <br/>
      <br/>
      <div className="container">
      <div className="vertical-center">
        <button id="btn" className="btn" onClick={async () => await deposit()}>
            deposit
        </button>
      </div>
    </div>
    <br/>
    <br/>
    <br/>

    <div className="container">
      <div className="vertical-center">
        <button id="btn" className="btn" onClick={async () => props.setRenderer(5)}>
            skip
        </button>
      </div>
    </div>
    </>
  )
}

const Redeem = (props) => {
  const [ens, setENS] = useState<any>()

  const redeem = () => {
    console.log(apWineStateChange)
    props.setRouter(++apWineStateChange)
  }

  return(
    <>
      <p>redeem :: $</p>
      <br/>
      <br/>
      <br/>
      {
        localStorage.getItem('aura')
      }
      <br/>
      <br/>
      <Dex setENS={setENS}/>
      <br/>
      <p>signing transaction with {ens}</p>
      <br/>
      <br/>
      <div className="container">
      <div className="vertical-center">
        <button id="btn" className="btn" onClick={() => redeem()}>
            🟆
        </button>
      </div>
    </div>
    </>
  )
}

const Swap = (props) => {
  return(
    <>
      <p>swap :: $</p>
      <br/>
      <br/>
      <br/>
      <div className="container">
      <div className="vertical-center">
        <button id="btn" className="btn" onClick={() => {
          props.setRenderer(5)
          apWineStateChange = 1
        }}>
            🟆
        </button>
      </div>
    </div>
    </>
  )
}

const Apwine = (router, setRouter, setRenderer, apWine) => {
  let cup;
  switch(router){
    case 1:
      cup = <Deposit setRenderer={setRenderer} setRouter={setRouter} apWine={apWine}/>
      break
    case 2:
      cup = <Redeem setRouter={setRouter} apWine={apWine}/>
      break;
    case 3:
      cup = <Swap setRenderer={setRenderer} apWine={apWine}/>
      break;
    default:
      cup = <p> 403 </p>
      break;
  }
  return cup
}

let apWine = 1
let apWineStateChange = 1
function Liquiduty(props){
  const [halt, setHalt] = useState(false)
  const [router, setRouter] = useState(1)
  const [deposit, setDeposit] = useState('')
  const [redeem, setRedeem] = useState('')
  const [swap, setSwap] = useState('')

  useEffect(() => {
    if(!halt) {
      setInterval(() => {
        if(apWine == 1){
            setDeposit('is-active')
            setRedeem('')
            setSwap('')

          }else if(apWine == 2){
            setDeposit('is-active')
            setRedeem('is-active')
            setSwap('')
          } else if(apWine == 3){
            setDeposit('is-active')
            setRedeem('is-active')
            setSwap('is-active')
            apWine = 0;
          }
          apWine++
      }, 1000)
    }
      setHalt(true)
  })
  return( 
    <>
      <h1 className="title">Liquiduty</h1>
      <br/>
      <br/>
      <br/>
      <br/>
      <section>
      <h2>Apwine</h2>
      <ol className="progress-bar">
        <li style={{textAlign: 'left'}} className={deposit}><span>Deposit</span></li>  
        <li className={redeem}><span>Redeem</span></li>  
        <li className={swap}><span>Swap</span></li>
      </ol>
    </section>

    <br/>
    <br/>
    {
      Apwine(router, setRouter, props.setRenderer, apWine)
    }
    <br/>
    <br/>
    <Banner />
    </>
  )
}

async function postData(url = '', data = {}) {
  // Default options are marked with *
  const response = await fetch(url, {
    method: 'POST', // *GET, POST, PUT, DELETE, etc.
    mode: 'cors', // no-cors, *cors, same-origin
    cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
    credentials: 'same-origin', // include, *same-origin, omit
    headers: {
      'Content-Type': 'application/json'
      // 'Content-Type': 'application/x-www-form-urlencoded',
    },
    redirect: 'follow', // manual, *follow, error
    referrerPolicy: 'no-referrer', // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
    body: JSON.stringify(data) // body data type must match "Content-Type" header
  });
  return response.json(); // parses JSON response into native JavaScript objects
}

// pulling REVERSED_NINE_OF_SWORDS on this one
const spindle = (card) => {
  if(card == undefined) return "X"
  console.log(card)
  const modifiedCard = card.split(' ')
  console.log(modifiedCard)
  let numeric;

  if(modifiedCard[1]){

    const cardStaked = n3pthora.filter((el,i) => {
      console.log(el)
      console.log(card)
      if(card == el[1]) numeric = i
      return card == el[1]
    })
    console.log(cardStaked)
  }else {
    const cardStaked = tarot.filter((el,i) => {
      console.log(el)
      console.log(modifiedCard[0])
      if(modifiedCard[0] == el) numeric = i
      return modifiedCard[0] == el[1]
    })
    console.log(cardStaked)
  }

  return numeric
}

function birch(cursor){
  if(cursor == undefined) return "https://i.ibb.co/BVdYPHL/stack8-dc7e14e434440a989dd6.png"
  else return cursor
}

function ir(peerId){
  console.log(peerId)
  let spirit: any = []
  const rad = 13
  let total = 0
  if(peerId){
    // console.log(String(peerId).length)
    for(let i = 0; i < peerId.length + 1; i++) {
      if(i % rad || i == 0) {
        // console.log(peerId.charCodeAt(i))
        total += peerId.charCodeAt(i)
      } else {
        // console.log(i)
        // console.log(total)
        // console.log(library[total % 256])
        spirit.push(library.library[total % 256])
        total = 0
      }
    }
    // console.log(library)
    return `${spirit[0]}-${spirit[1]}-${spirit[2]}-${spirit[3]}`
  }else return null
}

async function lir(peerIdPromise){
  // console.log(await peerIdPromise)
  // const peerId = (await peerIdPromise).Libp2pPeerId.toB58String()
  const seedArray = (await peerIdPromise)
  // if(typeof peerId == KeyPair) {
  //   // peerId = peerId.
  // }
  // console.log(seedArray)
  await Fluence.start({
    connectTo: relayNode,
    KeyPair: await KeyPair.fromEd25519SK(seedArray)
  })

  const peerId = Fluence.getStatus().peerId
  console.log('peerId')
  console.log(peerId)

  let spirit: any = []
  if(peerId){
    const rad = 13
    let total = 0
    // console.log(String(peerId).length)
    for(let i = 0; i < peerId.length + 1; i++) {
      if(i % rad || i == 0) {
        // console.log(peerId.charCodeAt(i))
        total += peerId.charCodeAt(i)
      } else {
        // console.log(i)
        // console.log(total)
        // console.log(library[total % 256])
        spirit.push(library.library[total % 256])
        total = 0
      }
    }
  }
  console.log('LIBRARY')
  console.log(library)
  return `${spirit[0]}-${spirit[1]}-${spirit[2]}-${spirit[3]}`
}

async function lr(peerIdPromise){
  console.log(await peerIdPromise)
  // const peerId = (await peerIdPromise).Libp2pPeerId.toB58String()
  const seedArray = (await peerIdPromise)
  // if(typeof peerId == KeyPair) {
  //   // peerId = peerId.
  // }
  console.log(seedArray)
  await Fluence.start({
    connectTo: relayNode,
    KeyPair: await KeyPair.fromEd25519SK(seedArray)
  })

  const peerId = Fluence.getStatus().peerId
  console.log('peerId')
  console.log(peerId)

  let spirit: any = []
  if(peerId){
    const rad = 13
    let total = 0
    // console.log(String(peerId).length)
    for(let i = 0; i < peerId.length + 1; i++) {
      if(i % rad || i == 0) {
        // console.log(peerId.charCodeAt(i))
        total += peerId.charCodeAt(i)
      } else {
        // console.log(i)
        // console.log(total)
        // console.log(library[total % 256])
        spirit.push(total % 256)
        total = 0
      }
    }
  }
  return {
    1:spirit[0],
    2:spirit[1],
    3:spirit[2],
    4:spirit[3]
  }
}

async function Vault(fromStore = false) {
  // const keyString = localStorage.getItem('⚂')
  const keyString = localStorage.getItem('⚅')

  // console.log(keyString)
  // console.log(keyString == null)
  // console.log(!fromStore)

  if(keyString == null || !fromStore) {
    const keyString = (await KeyPair.randomEd25519()).toEd25519PrivateKey()
    localStorage.setItem('⚂', String(keyString)) // 3 is dox
    return keyString
  } else if(fromStore) {
    // console.log(keyString)
    return new Uint8Array(keyString.split(',').map((num) => Number(num)))

  }
  // else return await KeyPair.fromEd25519SK(new Uint8Array(keyString.split(',').map((num) => Number(num))))
}

function Share(props){
  const [spirit, setSpirit] = useState<any>()
  const [peerId, setPeerId] = useState<any>()

  useEffect(() => {
    setSpirit(ir(window.location.href.split('/#/')[1]))
  })
  const addPeer = () => {
    console.log('coffee')
    setPeerId(window.location.href.split('/#/')[1])
    // add to storage
    setPeerId(window.location.href.split('/#/')[1])
    const nonceShare = localStorage.getItem('share')
    if(nonceShare == null){
      localStorage.setItem('share', String(0))
    }
    localStorage.setItem(`share:${Number(localStorage.getItem('share')) % 8}`, window.location.href.split('/#/')[1])
    localStorage.setItem('share', String(Number(localStorage.getItem('share'))+1))
    props.setRenderer(5)
  }

  return(
    <>
      <br/>
      <br/>
      <h1 className="title">add peer</h1>
      <br/>
      <br/>
      <br/>
      <br/>
      {peerId}
      {spirit}
      <br/>
      <br/>
      <p>you will be able to view this peer's cards</p>
      <br/>
      <br/>
      <br/>
      <div className="container">
      <div className="vertical-center">
        <div className="btn btn__secondary" style={{fontSize: '50px'}} onClick={()=> addPeer()}><p>A D D</p></div>
          {/*{Fluence.getStatus().isConnected ? '🟆' : 'ON'}*/}
      </div>
      </div>
    </>
  )
}

function Phone(props){
  const [phone, setPhone] = useState<any>();
  const [consent, setConsent] = useState<any>();
  const [phoneSuccess, setPhoneSuccess] = useState<any>();
  const [spirit, setSpirit] = useState<any>('');

  useEffect( () => {
    Fluence.start({ connectTo: relayNode })
      .catch((err) => console.log("Client initialization failed", err));
      console.log(Fluence.getStatus().peerId)
  })
  const phoneText = async () => {
    // write to local storage

    // console.log(keypair)
    // console.log((await KeyPair.randomEd25519()).Libp2pPeerId.privKey)
    // const keyString = String((await KeyPair.randomEd25519()).toEd25519PrivateKey())
    // // console.log((await KeyPair.randomEd25519())._privKey._key)
    // await Fluence.start({
    //   connectTo: relayNode,
    //   KeyPair: await KeyPair.fromEd25519SK(new Uint8Array(keyString.split(',').map((num) => Number(num))))
    // })
    const peerId = Fluence.getStatus().peerId
    console.log(peerId)
    // console.log(keyString)
    // console.log(await Vault(true))
    console.log(await lir(Vault(true)))
    // console.log()
    
    // const keypair = new KeyPair(peerId as any)
    // console.log(keypair.toEd25519PrivateKey())

    // localStorage.setItem('⚀', keyString)
    // localStorage.setItem('⚂', String(await Vault(true)))
    localStorage.setItem('⚅', String(await Vault(true)))



    let postBody = {
      phone: phone,
      spirit: await lir(Vault(true)),
      consent: consent,
      peerId: peerId
    }

    const res = postData('http://localhost:3001/index/sms', postBody)
    .then((data) => {
      console.log(data); // JSON data parsed by `data.json()` call
      setPhoneSuccess(true)
    });

  }

  const radioHandler = (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log(event.target.value)
    if(event.target.value == 'on') setConsent(true)
    // setConsent(event.target.value);
  };

  return(
    <>
      <br/>
      <br/>
      <p>share spirit</p>
      <br/>
      {/*{lir(Fluence.getStatus().peerId! ? Fluence.getStatus().peerId! : "12D3KooWR4cv1a8tv7pps4HH6wePNaK6gf1Hww5wcCMzeWxyNw51")}*/}
      {/*{lir(Fluence.getStatus().peerId! ? Fluence.getStatus().peerId! : "12D3KooWDaWxv4tMD6DtBBenE6jNUL6mNtM2zsHKZgfVcEhGwgyB")}*/}
      {spirit}
      <br/>
      <br/>
      <input className="radio__1" type="radio" id="html" name="fav_language" onChange={radioHandler}/>
      <br/>
      <br/>
      <br/>
        { phoneSuccess ? (
        <>
          <p>text should be on it's way</p>
          <br/>
          <br/>
          <div className="container">
            <div className="vertical-center">
              <div className="btn btn__secondary" onClick={()=> props.setRenderer(5)}><p>s e e &nbsp;&nbsp; s t a k e</p></div>
            </div>
          </div>
        </>) : <input className="input" onChange={async (e) => {
          setPhone(e.target.value)
          setSpirit(await lir(Vault(true)))
        // console.log(emailField)
          }} placeholder="#phone"></input>
        }
      <br/>
      <br/>
      <br/>
      <div className="container">
      { !phoneSuccess ? <div className="vertical-center">
        <div className="btn btn__secondary" style={{fontSize: '50px'}} onClick={()=> phoneText()}><p>T E X T</p></div>
          {/*{Fluence.getStatus().isConnected ? '🟆' : 'ON'}*/}
      </div> : null 
      }
      </div>
    </>
  )
}

function Email(props){
  const [emailField, setEmailField] = useState('')
  const [consent, setConsent] = useState(false)
  const [emailSuccess, setEmailSuccess] = useState(false)

  const email = () => {
    console.log('Emailing')

    // get from email onput
    const postBody = {
      email: emailField,
      one: `${spindle(RootStore(0)?.cursor)}_${new Date(Number(RootStore(0)?.time))}`,
      oneEmail: `${birch(RootStore(0)?.cursor)}`,
      two: `${spindle(RootStore(1)?.cursor)}_${new Date(Number(RootStore(1)?.time))}`,
      twoEmail: `${birch(RootStore(1)?.cursor)}`,
      three: `${spindle(RootStore(2)?.cursor)}_${new Date(Number(RootStore(2)?.time))}`,
      threeEmail: `${birch(RootStore(2)?.cursor)}`,
      four: `${spindle(RootStore(3)?.cursor)}_${new Date(Number(RootStore(2)?.time))}`,
      fourEmail: `${birch(RootStore(3)?.cursor)}` ,
      five: `${spindle(RootStore(4)?.cursor)}_${new Date(Number(RootStore(2)?.time))}`,
      fiveEmail: `${birch(RootStore(4)?.cursor)}` ,
      six: `${spindle(RootStore(5)?.cursor)}_${new Date(Number(RootStore(2)?.time))}`,
      sixEmail: `${birch(RootStore(5)?.cursor)}` ,
      seven: `${spindle(RootStore(6)?.cursor)}_${new Date(Number(RootStore(2)?.time))}`,
      sevenEmail: `${birch(RootStore(6)?.cursor)}` ,
      eight: `${spindle(RootStore(7)?.cursor)}_${new Date(Number(RootStore(2)?.time))}`,
      eightEmail: `${birch(RootStore(7)?.cursor)}` ,
      consent: consent
    }

    const res = postData('http://localhost:3001/index/', postBody)
    // const res = postData('https://reed.live/index/', postBody)
    .then((data) => {
      console.log(data); // JSON data parsed by `data.json()` call
      setEmailSuccess(true)
    });

    // const res = fetch('localhost:3001/index', {

    // })

    console.log(res)
  }

  const radioHandler = (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log(event.target.value)
    if(event.target.value == 'on') setConsent(true)
    // setConsent(event.target.value);
  };



  useEffect(() => {
    // const el = document.getElementsByName("fav_language")
    // console.log(el)


    // el[0].addEventListener('click', function() {
    //   // let result = document.getElementById('html')
    //   let radio = (document.querySelector('[name="fav_language') as HTMLInputElement).value
    //   // let radio = <HTMLInputElement>document?.querySelector('[name="fav_language"]:checked')
    //   console.log(radio)
    //   let xo = true as any

    //   if((document.querySelector('[name="fav_language') as HTMLInputElement).value){
    //     console.log('xo')
    //     console.log(xo)
    //     xo = false
    //   }

    //   (document.querySelector('[name="fav_language') as HTMLInputElement).checked = xo
    //   // let value = document?.querySelector('[name="fav_language"]:checked')?.value
    //   // console.log('value')
    //   // console.log(value)
    //   // setConsent(value)
    // })
  })

  return(
    <>
      <h1 className="title">Email</h1>
      <br/>
      <div className="container">
      </div>
      <br/>
      <br/>
      <br/>
      <p>consent to recieve a 12 day whl dial for the upcoming cycle?</p> 
      <br/>
      <br/>
      <p><a href="https://github.com/livepeer/Grant-Program/issues/69" target="_blank"> ☂ note</a>: refresh & pass through, to deselect</p>
      <br/>
      <br/>

      <input className="radio__1" type="radio" id="html" name="fav_language" onChange={radioHandler}/>
      <br/>
      <br/>
      <br/>
      <br/>
      
       { emailSuccess ? <p>email should be on it's way</p> : <input className="input" onChange={(e) => {
        setEmailField(e.target.value)
        console.log(emailField)
          }} placeholder="@email"></input>
        }
        <br/>
        <br/>
        <br/>
        <br/>

        <br/>
        <br/>

      { emailSuccess ? <div>
      <div className="container">
            <div className="vertical-center">
              <div className="btn btn__secondary" onClick={()=> props.setRenderer(5)}><a><p>s e e s t a k e</p></a></div>
            </div>
            </div>
          </div> : (<><br/><br/>
        <div className="btn btn__secondary" style={{marginLeft: '45%'}} onClick={()=> email()}><h3>e m a i l</h3></div>
          {/*{Fluence.getStatus().isConnected ? '🟆' : 'ON'}*/}
      </>)
      }
    </>
  )
}

function Willow(props){
  return (
    <>
      <h1></h1>
    </>
  )
}

// Thanks
const Compass = (props, setRenderer, deck, setDeck, relayNode, setAssembled, assembled) => {
  let needle;
  // like a quilt
  switch(props){
    case 1:
      needle = <Reed setRenderer={setRenderer} setAssembled={setAssembled}/>
      break;
    case 2:
      needle = <Setting setRenderer={setRenderer} deck={deck} setDeck={setDeck}/>
      break;
    case 3:
      needle = <Spread setRenderer={setRenderer} deck={deck} relayNode={relayNode} assembled={assembled} setAssembled={setAssembled}/>
      break;
    case 4:
      needle = <Liquiduty setRenderer={setRenderer} />
      break;
    case 5:
      needle = <Stake setRenderer={setRenderer}/>
      break;
    case 6:
      needle = <Email setRenderer={setRenderer}/>
      break;
    case 7:
      needle = <Phone setRenderer={setRenderer}/>
      break;
    case 8:
      needle = <Share setRenderer={setRenderer}/>
      break;
    case 9:
      needle = <Willow setRenderer={setRenderer}/>
      break;
    case 10:
      needle = <Profile setRenderer={setRenderer}/>
      break;
    default:
      needle = <h4>404</h4>
  }

  return needle
}

function App() {
  const [assembled, setAssembled] = useState<any>(false)
  const [halt, setHalt] = useState(false)
  const [deck, setDeck] = useState(null)
  const [renderer, setRenderer] = useState(2)
  const [intervaling, setIntervaling] = useState(null)
  const [relayTime, setRelayTime] = useState<Date | null>(null);
  const [fluenceMod, setFluenceMod] = useState<any>(null);
  // const [fluenceMod, setFluenceMod] = useState<any>(null);



  useEffect(() => {
    const url = window.location.href
    console.log(url.split('/#/')[1])
    const nonceShare = localStorage.getItem('share')
    if(nonceShare == null){
      localStorage.setItem('share', String(0))
    }
    const peerId = url.split('/#/')[1]
    if(peerId){
      setRenderer(8)
    }
    // const rootStore = new ShareStore(peerId, localStorage.getItem('share'))
    // rootStore ? rootStore.share(url.split('/#/')[1], localStorage.getItem('share')) : null

    const nonce = localStorage.getItem('nonce')
    if(nonce == null){
      localStorage.setItem('nonce', String(0))
    }
    Fluence.start({ connectTo: relayNode })
      .catch((err) => console.log("Client initialization failed", err));
  }, []);

  const onGetRelayTimeBtnClick = async () => {
    if (!Fluence.getStatus().isConnected) {
      Fluence.start({ connectTo: relayNode }).catch((err) => console.log("Client initialization failed", err));
      return;
    }



    const time = await getRelayTime(relayNode.peerId);
    setRelayTime(new Date(time));
    if(Fluence.getStatus().isConnected){
      await Off()
    }
  };

  const Off = async () => {
    await Fluence.stop()
  }

  return (
    <div className="App">
      <div className="content">
        <h1>P 2 P: <span id="status">{Fluence.getStatus().isConnected ? '🟢' : '🔴'}</span></h1>
        <button style={{marginLeft: "14px"}} id="btn" className="btn" onClick={onGetRelayTimeBtnClick}>
          {Fluence.getStatus().isConnected ? 'ϕ' : 'ON'}
        </button>
        {relayTime && (
          <>
            <h2>Relay time:</h2>
            <div id="relayTime">{relayTime?.toLocaleString() || ""}</div>
          </>
        )}
      </div>
      {
        Compass(renderer, setRenderer, deck, setDeck, relayNode, setAssembled, assembled)
      }
    </div>
  );
}

export default App;

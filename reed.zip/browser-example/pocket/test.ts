import {Fluence} from '@fluencelabs/fluence'
import { krasnodar } from '@fluencelabs/fluence-network-environment'
import PocketDB from './PocketDB'
import hypertrie from 'hypertrie'
import { tsMethodSignature } from '@babel/types'
import {
    //line 392, w/ peer
    getRelayTime, // Q: what's the difference between a mark in the urbit hoon programming language and a particle definition with a fluence blueprint?
    
    // line 258 w/ peer
    postReview,

    // line 477 w/ peer
    getReducedReviews,

    // line 592 w/peer
    addDeck
} from './generated_aqua/reed'

// import { Script } from 'vm'
// const db = hypertrie('./trie.db', {valueEncoding: 'json', alwaysUpdate: true, alwaysReconnect: true, lock: false})

async function main(PEER_ID){
    // const pdb = new PocketDB(db)
    // test deck upload
    // console.log("Inserting: ", await pdb.append("hod", ["1,2,3","4,5,6"]))
    // console.log("Retrieving: ", await pdb.look("hod"))
    // console.log("Oll-ie", await pdb.everything())

    await Fluence.start({
        connectTo: krasnodar[0]
        // seedArray: await lir(Vault(true)) // ya true
    })
    console.log(await getRelayTime(Fluence.getStatus().relayPeerId))
    console.log('connected:', Fluence.getStatus().peerId)
    const signature = ""
    // console.log(await postReview(PEER_ID, Fluence.getStatus().relayPeerId,"n3pthora", signature, "0x73A73A",5, {ttl: }))
    var ttl = new Date();
    ttl.setDate(ttl.getDate() + 40);
    /* 

        const ad = await matter.direct.reed.addDeck(PEER_ID, __, ___, ____, _____, "n3pthora", [...|,,|])

    */
    // describe: it should add a deck and return whether the deck is unique
    // targetPeerId: PeerId, targetRelayPeerId: PeerId, address: string, signature: string, title: string, deck: []string
    // const ad = await addDeck(PEER_ID, Fluence.getStatus().relayPeerId, "0x", "signature", "n3pthora", [""], new Date())
    const ad = await addDeck(PEER_ID, Fluence.getStatus().relayPeerId, "0x", "signature", "n3pthora", ["1,2,3"])
    console.log(ad)

    // console.log(await postReview(PEER_ID, Fluence.getStatus().relayPeerId,"n3pthora", signature, "0x73A73A",5, {ttl: ttl.getMilliseconds()}))
    // const pr =  await postReview(PEER_ID, Fluence.getStatus().relayPeerId,"n3pthora", signature, "0x73A73A",5)
    // console.log(pr)

    // describe: it should get an average review rating for a deck
    // const grr = await getReducedReviews(PEER_ID, Fluence.getStatus().relayPeerId, "n3pthora")
    // console.log(grr)


}

main("12D3KooWNSAtdbZJZ7aRwMpruAzWm4a97YYGrVvP42qHW5DngSgj")

/* TODO
    - write a README
    - create tests for backend in a script, testing Reviews service 
    - integrate front end epxerience 
        - reviews
        - decks
*/

// review -> retroactive funding?